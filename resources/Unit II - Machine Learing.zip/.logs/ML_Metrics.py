# Wed, 18 Mar 2020 17:49:03
%logstop
%logstart -ortq ~/.logs/ML_Metrics.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_Metrics.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
# Wed, 18 Mar 2020 17:49:03
import matplotlib.pyplot as plt
import pandas as pd
import sklearn.datasets# Wed, 18 Mar 2020 17:49:03
!wget http://dataincubator-wqu.s3.amazonaws.com/caldata/cal_housing.pkz -nc -P ~/scikit_learn_data/# Wed, 18 Mar 2020 17:49:03
from sklearn.datasets import fetch_california_housing

cali_data = fetch_california_housing()

print(cali_data.DESCR)

cali_df = pd.DataFrame(cali_data.data, columns=cali_data.feature_names)
cali_df.head()#[Out]#    MedInc  HouseAge  AveRooms  AveBedrms  Population  AveOccup  Latitude  \
#[Out]# 0  8.3252      41.0  6.984127   1.023810       322.0  2.555556     37.88   
#[Out]# 1  8.3014      21.0  6.238137   0.971880      2401.0  2.109842     37.86   
#[Out]# 2  7.2574      52.0  8.288136   1.073446       496.0  2.802260     37.85   
#[Out]# 3  5.6431      52.0  5.817352   1.073059       558.0  2.547945     37.85   
#[Out]# 4  3.8462      52.0  6.281853   1.081081       565.0  2.181467     37.85   
#[Out]# 
#[Out]#    Longitude  
#[Out]# 0    -122.23  
#[Out]# 1    -122.22  
#[Out]# 2    -122.24  
#[Out]# 3    -122.25  
#[Out]# 4    -122.25  
# Wed, 18 Mar 2020 17:49:03
print(cali_data.data.shape)
print(cali_data.target.shape)# Wed, 18 Mar 2020 17:49:03
from sklearn import metrics
import numpy as np

y = np.random.randn(10)
y_pred = y + .5 * np.random.randn(10)

print('MSE: %f' % metrics.mean_squared_error(y, y_pred))
print('MAE: %f' % metrics.mean_absolute_error(y, y_pred))
print('R^2: %f' % metrics.r2_score(y, y_pred))# Wed, 18 Mar 2020 17:49:03
# rescale y

y = 2 * y
y_pred = 2 * y_pred

print('MSE: %f' % metrics.mean_squared_error(y, y_pred))
print('MAE: %f' % metrics.mean_absolute_error(y, y_pred))
print('R^2: %f' % metrics.r2_score(y, y_pred))# Wed, 18 Mar 2020 17:49:03
y = [0, 0, 1, 0, 1, 1, 0, 1]
y_pred = [0, 1, 1, 0, 1, 1, 0, 1]

print('Accuracy: %f' % metrics.accuracy_score(y, y_pred))
print('Recall: %f' % metrics.recall_score(y, y_pred))
print('Precision: %f' % metrics.precision_score(y, y_pred))# Wed, 18 Mar 2020 17:49:03
p_pred = np.linspace(0, 1, 1000)
y = np.random.binomial(1, p_pred)# Wed, 18 Mar 2020 17:49:03
precisions, recalls, thresholds = metrics.precision_recall_curve(y, p_pred)

plt.plot(recalls, precisions)
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision v. Recall');# Wed, 18 Mar 2020 17:49:03
%logstop
%logstart -ortq ~/.logs/ML_Metrics.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_Metrics.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
%logstop
%logstart -ortq ~/.logs/ML_Metrics.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
import matplotlib.pyplot as plt
import pandas as pd
import sklearn.datasets
!wget http://dataincubator-wqu.s3.amazonaws.com/caldata/cal_housing.pkz -nc -P ~/scikit_learn_data/
from sklearn.datasets import fetch_california_housing

cali_data = fetch_california_housing()

print(cali_data.DESCR)

cali_df = pd.DataFrame(cali_data.data, columns=cali_data.feature_names)
cali_df.head()
#[Out]#    MedInc  HouseAge  AveRooms  AveBedrms  Population  AveOccup  Latitude  \
#[Out]# 0  8.3252      41.0  6.984127   1.023810       322.0  2.555556     37.88   
#[Out]# 1  8.3014      21.0  6.238137   0.971880      2401.0  2.109842     37.86   
#[Out]# 2  7.2574      52.0  8.288136   1.073446       496.0  2.802260     37.85   
#[Out]# 3  5.6431      52.0  5.817352   1.073059       558.0  2.547945     37.85   
#[Out]# 4  3.8462      52.0  6.281853   1.081081       565.0  2.181467     37.85   
#[Out]# 
#[Out]#    Longitude  
#[Out]# 0    -122.23  
#[Out]# 1    -122.22  
#[Out]# 2    -122.24  
#[Out]# 3    -122.25  
#[Out]# 4    -122.25  
print(cali_data.data.shape)
print(cali_data.target.shape)
from sklearn import metrics
import numpy as np

y = np.random.randn(10)
y_pred = y + .5 * np.random.randn(10)

print('MSE: %f' % metrics.mean_squared_error(y, y_pred))
print('MAE: %f' % metrics.mean_absolute_error(y, y_pred))
print('R^2: %f' % metrics.r2_score(y, y_pred))
# rescale y

y = 2 * y
y_pred = 2 * y_pred

print('MSE: %f' % metrics.mean_squared_error(y, y_pred))
print('MAE: %f' % metrics.mean_absolute_error(y, y_pred))
print('R^2: %f' % metrics.r2_score(y, y_pred))
y = [0, 0, 1, 0, 1, 1, 0, 1]
y_pred = [0, 1, 1, 0, 1, 1, 0, 1]

print('Accuracy: %f' % metrics.accuracy_score(y, y_pred))
print('Recall: %f' % metrics.recall_score(y, y_pred))
print('Precision: %f' % metrics.precision_score(y, y_pred))
p_pred = np.linspace(0, 1, 1000)
y = np.random.binomial(1, p_pred)
precisions, recalls, thresholds = metrics.precision_recall_curve(y, p_pred)

plt.plot(recalls, precisions)
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision v. Recall');
