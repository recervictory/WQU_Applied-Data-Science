# Wed, 18 Mar 2020 17:41:35
%logstop
%logstart -ortq ~/.logs/ML_Anomaly_Detection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:42:21
%logstop
%logstart -ortq ~/.logs/ML_Classification.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:42:30
%logstop
%logstart -ortq ~/.logs/ML_Classification.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:43:31
%logstop
%logstart -ortq ~/.logs/ML_Clustering.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:44:01
%logstop
%logstart -ortq ~/.logs/ML_Clustering.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:46:27
%logstop
%logstart -ortq ~/.logs/ML_Tree_Based_Models.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:46:35
%logstop
%logstart -ortq ~/.logs/ML_Tree_Based_Models.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:47:40
%logstop
%logstart -ortq ~/.logs/ML_Clustering.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:47:47
%logstop
%logstart -ortq ~/.logs/ML_Clustering.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:48:20
%logstop
%logstart -ortq ~/.logs/ML_Metrics.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:49:02
%logstop
%logstart -ortq ~/.logs/ML_Metrics.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:49:47
%logstop
%logstart -ortq ~/.logs/ML_Support_Vector_Machines.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:52:45
%logstop
%logstart -ortq ~/.logs/ML_Time_Series.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:53:34
%logstop
%logstart -ortq ~/.logs/ML_Tree_Based_Models.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:54:03
%logstop
%logstart -ortq ~/.logs/ML_Tree_Based_Models.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:54:57
%logstop
%logstart -ortq ~/.logs/ML_Tree_Based_Models.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:56:08
%logstop
%logstart -ortq ~/.logs/ML_Support_Vector_Machines.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:58:34
%logstop
%logstart -ortq ~/.logs/ML_Time_Series.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:58:51
%logstop
%logstart -ortq ~/.logs/ML_Time_Series.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:59:11
%logstop
%logstart -ortq ~/.logs/ML_Dimension_Reduction.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 17:59:34
%logstop
%logstart -ortq ~/.logs/ML_Dimension_Reduction.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:00:18
%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:00:46
%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:01:34
%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:02:10
%logstop
%logstart -ortq ~/.logs/ML_K_Nearest_Neighbors.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:02:22
%logstop
%logstart -ortq ~/.logs/ML_K_Nearest_Neighbors.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:02:50
%logstop
%logstart -ortq ~/.logs/ML_Natural_Language_Processing.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:02:59
%logstop
%logstart -ortq ~/.logs/ML_Natural_Language_Processing.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:03:08
%logstop
%logstart -ortq ~/.logs/ML_Natural_Language_Processing.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:03:13
%logstop
%logstart -ortq ~/.logs/ML_FeatureEngineering.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:03:44
%logstop
%logstart -ortq ~/.logs/ML_FeatureEngineering.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:03:55
%logstop
%logstart -ortq ~/.logs/ML_FeatureEngineering.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:12:14
%logstop
%logstart -ortq ~/.logs/ML_Natural_Language_Processing.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:12:57
%logstop
%logstart -ortq ~/.logs/ML_Natural_Language_Processing.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:13:05
%logstop
%logstart -ortq ~/.logs/ML_Natural_Language_Processing.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:15:14
%logstop
%logstart -ortq ~/.logs/ML_Intro_ML.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144# Wed, 18 Mar 2020 18:15:46
%logstop
%logstart -ortq ~/.logs/ML_LinearRegression.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144