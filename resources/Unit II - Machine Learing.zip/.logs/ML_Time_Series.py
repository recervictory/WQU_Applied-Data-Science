# Wed, 18 Mar 2020 17:52:45
%logstop
%logstart -ortq ~/.logs/ML_Time_Series.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_Time_Series.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
# Wed, 18 Mar 2020 17:52:45
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd# Wed, 18 Mar 2020 17:52:45
from sklearn.linear_model import Ridge
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit

regressor = Ridge()
param_grid = {"alpha": np.logspace(-2, 2, 100)}
ts_cv = TimeSeriesSplit(5) # 5-fold forward chaining
grid_search = GridSearchCV(regressor, param_grid, cv=ts_cv, n_jobs=2)# Wed, 18 Mar 2020 17:52:45
from ipywidgets import interact, FloatSlider

def plot_signal(rho=0):
    n = 1000
    np.random.seed(0)

    eps = np.random.randn(n)
    y = np.zeros(n)
    y[0] = eps[0]
    var = np.zeros(n)
    
    for i in range(1, n):
        y[i] = rho*y[i-1] + eps[i]
        var[i] = y[:i].var()

    plt.subplot(211)
    plt.plot(y)
    plt.ylabel('y')

    plt.subplot(212)
    plt.plot(var)
    plt.ylabel('$\sigma_y$')    
    plt.plot(var)

interact(plot_signal, rho=FloatSlider(min=0, max=1, value=0, step=0.01, description='$\\rho$'));# Wed, 18 Mar 2020 17:52:46
# load data set
columns = ['year', 'month', 'day', 'decimal date', 'molfrac', 'days', '1 yr ago', '10 yrs ago', 'since 1880']
df = pd.read_csv('data/co2_weekly_mlo.txt', sep='\s+', header=None, names=columns, na_values=-999.99)

# create timestamp indices
df['date'] = pd.to_datetime(df[['year', 'month', 'day']])
df = df.set_index('decimal date')

# replace missing values
df['molfrac'] = df['molfrac'].fillna(method='ffill')

df.head()#[Out]#               year  month  day  molfrac  days  1 yr ago  10 yrs ago  \
#[Out]# decimal date                                                          
#[Out]# 1974.3795     1974      5   19   333.34     6       NaN         NaN   
#[Out]# 1974.3986     1974      5   26   332.95     6       NaN         NaN   
#[Out]# 1974.4178     1974      6    2   332.32     5       NaN         NaN   
#[Out]# 1974.4370     1974      6    9   332.18     7       NaN         NaN   
#[Out]# 1974.4562     1974      6   16   332.37     7       NaN         NaN   
#[Out]# 
#[Out]#               since 1880       date  
#[Out]# decimal date                         
#[Out]# 1974.3795          50.36 1974-05-19  
#[Out]# 1974.3986          50.06 1974-05-26  
#[Out]# 1974.4178          49.57 1974-06-02  
#[Out]# 1974.4370          49.63 1974-06-09  
#[Out]# 1974.4562          50.07 1974-06-16  
# Wed, 18 Mar 2020 17:52:46
CO2 = df['molfrac']
CO2.plot()
plt.ylabel('CO2 ppm');# Wed, 18 Mar 2020 17:52:46
from sklearn.base import BaseEstimator, TransformerMixin

class IndexSelector(BaseEstimator, TransformerMixin):
    def __init__(self):
        """Return indices of a data frame for use in other estimators."""
        pass
    
    def fit(self, df, y=None):
        return self
    
    def transform(self, df):
        indices = df.index
        return indices.values.reshape(-1, 1)# Wed, 18 Mar 2020 17:52:46
def ts_train_test_split(df, cutoff, target):
    """Perform a train/test split on a data frame based on a cutoff date."""
    
    ind = df.index < cutoff
    
    df_train = df.loc[ind]
    df_test = df.loc[~ind]
    y_train = df.loc[ind, target]
    y_test = df.loc[~ind, target]
    
    return df_train, df_test, y_train, y_test

def plot_results(df, y_pred):
    """Plot predicted results and residuals."""
    
    CO2.plot();
    plt.plot(list(df.index), y_pred, '-r');
    plt.xlabel('year')
    plt.ylabel('CO2 ppm')
    plt.legend(['true', 'predicted']);
    plt.show();

    plt.plot(resd)
    plt.xlabel('year')
    plt.ylabel('residual')# Wed, 18 Mar 2020 17:52:46
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures

# perform train/test split
cutoff = 2010
df_train, df_test, y_train, y_test = ts_train_test_split(df, cutoff, 'molfrac')

# construct and train pipeline
time = IndexSelector()
poly = PolynomialFeatures(degree=2)
lr = LinearRegression()
pipe = Pipeline([('indices', time),
                 ('drift', poly),
                 ('regressor', lr)])
pipe.fit(df_train, y_train)

# make predictions
y_pred = pipe.predict(df)
resd = CO2 - y_pred
print("Test set R^2: {:g}".format(pipe.score(df_test, y_test)))
plot_results(df, y_pred)# Wed, 18 Mar 2020 17:52:47
from scipy import fftpack

def fft_plot(a=1, b=1, c=1, fourier=True):
    np.random.seed(0)
    N = 100
    t_end = 4
    t = np.linspace(0, t_end, N)
    
    y = a*np.cos(2*np.pi*t) + b*np.sin(4*2*np.pi*t) + c*np.cos(8*2*np.pi*t) + 0.2*np.random.randn(N)
    Y = fftpack.fft(y)
    f = np.linspace(0, N, N)/t_end
    
    if fourier:
        plt.subplot(211)
        plt.plot(t, y)
        plt.xlim([0, 4])
        plt.ylim([-4, 4])
        plt.xlabel('time')
        
        plt.subplot(212)
        plt.plot(f, np.abs(Y)/len(Y))
        plt.ylim([0, 2])
        plt.xlabel('number of cyles in full window')
        plt.tight_layout()
    else:
        plt.plot(t, y)
        plt.xlim([0, 4])
        plt.ylim([-4, 4])
        plt.xlabel('time')

fft_plot(a=1, b=1, c=1, fourier=False);# Wed, 18 Mar 2020 17:52:47
from ipywidgets import interact

interact(fft_plot, a=(0, 4, 0.1), b=(0, 4, 0.1), c=(0, 4, 0.1));# Wed, 18 Mar 2020 17:52:47
from ipywidgets import FloatSlider

def plot_alias(f=0.2, blue=True, green=True):
    t = np.linspace(0, 10, 500)
    t_sampled = np.arange(0, 11)
    
    if blue:
        plt.plot(t, np.sin(2*np.pi*f*t), 'b')
    if green:
        plt.plot(t, -np.sin(2*np.pi*(1-f)*t), 'g')
        
    l, m, b = plt.stem(t_sampled, 
                       np.sin(2*np.pi*f*t_sampled), 
                       linefmt='r', 
                       markerfmt='ro',
                       use_line_collection=True)
    plt.setp(b, visible=False)
    plt.ylim(-2, 2)
    plt.xticks(t_sampled)
    plt.legend(["f={}".format(f), "f={}".format(1-f), "sampled signal"])

interact(plot_alias, f=FloatSlider(min=0, max=1.0, step=0.05, value=0.05, description='$f$'));# Wed, 18 Mar 2020 17:52:48
Y = fftpack.fft(resd-resd.mean())
t_span = CO2.index[-1] - CO2.index[0]
f = np.linspace(0, len(Y), len(Y))/t_span

plt.plot(f[:len(Y)//2], np.abs(Y[:len(Y)//2])/len(Y));
plt.xlabel('frequency (1/yr)')
plt.ylabel('amplitude');# Wed, 18 Mar 2020 17:52:48
plt.plot(f[:200], np.abs(Y)[:200]);
plt.xlabel('frequency (1/yr)')
plt.ylabel('amplitude');# Wed, 18 Mar 2020 17:52:48
from sklearn.base import BaseEstimator, TransformerMixin

class FourierComponents(BaseEstimator, TransformerMixin):
    def __init__(self, freqs):
        """Create features based on sin(2*pi*f*t) and cos(2*pi*f*t)."""
        self.freqs = freqs
    
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        Xt = np.zeros((X.shape[0], 2*len(self.freqs)))
        
        for i, f in enumerate(self.freqs):

            Xt[:, 2*i]= np.cos(2*np.pi*f*X).reshape(-1)
            Xt[:, 2*i + 1] = np.sin(2*np.pi*f*X).reshape(-1)
    
        return Xt# Wed, 18 Mar 2020 17:52:48
from sklearn.pipeline import FeatureUnion

# construct and train pipeline
fourier = FourierComponents([1, 2]) # annual and biannual frequencies
union = FeatureUnion([('drift', poly), ('fourier', fourier)])
baseline = Pipeline([('indices', time),
                 ('union', union),
                 ('regressor', lr)])
baseline.fit(df_train, y_train)

# make predictions
y_pred = baseline.predict(df)
resd = CO2 - y_pred
print("Test set R^2: {:g}".format(baseline.score(df_test, y_test)))
plot_results(df, y_pred)# Wed, 18 Mar 2020 17:52:49
from pandas.plotting import autocorrelation_plot

autocorrelation_plot(resd)
plt.xlabel('Lag (weeks)')
plt.xlim([0, 1000]);# Wed, 18 Mar 2020 17:52:49
def plot_rolling_window(window=10):
    series = pd.Series(resd, index=df.index)

    rolling_window = series.rolling(window=window).mean()
    series.plot(alpha=0.5)
    rolling_window.plot(linewidth=2, color='k')
    plt.title('rolling window')
    plt.xlabel('year')
    plt.ylabel('moving average')
    
interact(plot_rolling_window, window=(1, 200, 1));# Wed, 18 Mar 2020 17:52:49
def plot_exponential_weighted(half_life=100):
    series = pd.Series(resd, index=df.index)
    exponential_weighted = series.ewm(halflife=half_life).mean()
    
    series.plot(alpha=0.5)
    exponential_weighted.plot(linewidth=2, color='k')
    plt.title('exponential weighted')
    plt.xlabel('year')
    plt.ylabel('moving average')

half_life_slider = FloatSlider(min=1, max=100, step=0.1, value=10, description="half-life")
interact(plot_exponential_weighted, half_life=half_life_slider);# Wed, 18 Mar 2020 17:52:50
class ResidualFeatures(BaseEstimator, TransformerMixin):
    def __init__(self, window=100):
        """Generate features based on window statistics of past noise/residuals."""
        self.window = window
        
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        df = pd.DataFrame()
        df['residual'] = pd.Series(X, index=X.index)
        df['prior'] = df['residual'].shift(1)
        df['mean'] = df['residual'].rolling(window=self.window).mean()
        df['diff'] = df['residual'].diff().rolling(window=self.window).mean()
        df = df.fillna(method='bfill')
        
        return df# Wed, 18 Mar 2020 17:52:50
from sklearn.metrics import r2_score

# create and train residual model
resd_train = y_train - baseline.predict(df_train)
residual_feats = ResidualFeatures(window=100)
residual_model = Pipeline([('residual_features', residual_feats), ('regressor', LinearRegression())])
residual_model.fit(resd_train.iloc[:-20], resd_train.shift(-20).dropna())

# evaluate model
resd_pred = residual_model.predict(resd) # prediction for all time steps
resd_pred = pd.Series(resd_pred, index=df.index)
resd_pred = resd_pred.shift(20).dropna() # shift predicted values to matching time step
resd_pred_test = resd_pred.loc[resd_pred.index > 2010] # evaluate only on 2010 values
print("Residual test set R^2: {:g}".format(r2_score(resd.loc[resd.index > 2010], resd_pred_test)))# Wed, 18 Mar 2020 17:52:50
from sklearn.base import RegressorMixin

class FullModel(BaseEstimator, RegressorMixin):
    def __init__(self, baseline, residual_model, steps=20):
        """Combine a baseline and residual model to predict any number of steps in the future."""
        
        self.baseline = baseline
        self.residual_model = residual_model
        self.steps = steps
        
    def fit(self, X, y):
        self.baseline.fit(X, y)
        resd = y - self.baseline.predict(X)
        self.residual_model.fit(resd.iloc[:-self.steps], resd.shift(-self.steps).dropna())
                
        return self
    
    def predict(self, X):
        y_b = pd.Series(self.baseline.predict(X), index=X.index)
        resd = X['molfrac'] - y_b
        resd_pred = pd.Series(self.residual_model.predict(resd), index=X.index)
        resd_pred = resd_pred.shift(self.steps)
        y_pred = y_b + resd_pred
        
        return y_pred
    
# construct and train full model
full_model = FullModel(baseline, residual_model, steps=20)
full_model.fit(df_train, y_train)

# make predictions
y_pred = full_model.predict(df)
resd = CO2 - y_pred
ind = resd.index > 2010
print("Test set R^2: {:g}".format(r2_score(CO2.loc[ind], y_pred.loc[ind])))
plot_results(df, y_pred)# Wed, 18 Mar 2020 17:52:50
from scipy.stats import norm

mu = resd.mean()
sigma = resd.std(ddof=1)
dist = norm(mu, sigma)
x = np.linspace(-2, 2, 100)
f = dist.pdf(x)

resd.hist(bins=40, density=True)
plt.plot(x, f, '-r', linewidth=2);# Wed, 18 Mar 2020 17:52:51
autocorrelation_plot(resd.dropna())
plt.xlim([0, 100]);# Wed, 18 Mar 2020 17:52:51
type(df_train.date.to_numpy())#[Out]# numpy.ndarray
# Wed, 18 Mar 2020 17:52:51
from statsmodels.tsa.ar_model import AR

# create and fit AR model
lag = 200
resd_train = y_train - baseline.predict(df_train)
ar = AR(resd_train.values, dates=df_train['date'], freq='W')
ar = ar.fit(maxlag=lag)
resd_ar_train_pred = ar.predict(start=lag, end=len(df_train)-1)

# plot training set results
plt.plot(list(df_train.index), y_train - baseline.predict(df_train), alpha=0.5)
plt.plot(list(df_train.index[lag:]), resd_ar_train_pred, 'r')
plt.xlabel('year');
plt.ylabel('residual')
plt.legend(['true', 'predicted'])
plt.show();

# plot 20 step forecast of test set
steps = 20
resd_ar_test_pred = ar.predict(start=len(df_train), end=len(df_train) + steps - 1)
plt.plot(range(1, steps + 1), y_test.iloc[:steps] - baseline.predict(df_test.iloc[:steps]))
plt.plot(range(1, steps + 1), resd_ar_test_pred)
plt.xlabel('step')
plt.ylabel('residual')
plt.legend(['true', 'predicted']);# Wed, 18 Mar 2020 17:52:52
import pickle
from statsmodels.tsa.arima_model import ARIMA

# arima = ARIMA(resd_train.values, order=(20, 1, 5), dates=df_train['date'], freq='W')
# arima = arima.fit()

# load pretrained model
with open('data/arima_model.pkl', 'rb') as f:
    arima = pickle.load(f)

# plot 20 step forecast of test set
steps = 20
resd_arima_test_pred, _, _ = arima.forecast(steps)
plt.plot(range(1, steps + 1), resd_arima_test_pred)
plt.xlabel('step')
plt.ylabel('residual');# Wed, 18 Mar 2020 17:58:34
%logstop
%logstart -ortq ~/.logs/ML_Time_Series.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_Time_Series.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
# Wed, 18 Mar 2020 17:58:34
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd# Wed, 18 Mar 2020 17:58:34
from sklearn.linear_model import Ridge
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit

regressor = Ridge()
param_grid = {"alpha": np.logspace(-2, 2, 100)}
ts_cv = TimeSeriesSplit(5) # 5-fold forward chaining
grid_search = GridSearchCV(regressor, param_grid, cv=ts_cv, n_jobs=2)# Wed, 18 Mar 2020 17:58:34
from ipywidgets import interact, FloatSlider

def plot_signal(rho=0):
    n = 1000
    np.random.seed(0)

    eps = np.random.randn(n)
    y = np.zeros(n)
    y[0] = eps[0]
    var = np.zeros(n)
    
    for i in range(1, n):
        y[i] = rho*y[i-1] + eps[i]
        var[i] = y[:i].var()

    plt.subplot(211)
    plt.plot(y)
    plt.ylabel('y')

    plt.subplot(212)
    plt.plot(var)
    plt.ylabel('$\sigma_y$')    
    plt.plot(var)

interact(plot_signal, rho=FloatSlider(min=0, max=1, value=0, step=0.01, description='$\\rho$'));# Wed, 18 Mar 2020 17:58:34
# load data set
columns = ['year', 'month', 'day', 'decimal date', 'molfrac', 'days', '1 yr ago', '10 yrs ago', 'since 1880']
df = pd.read_csv('data/co2_weekly_mlo.txt', sep='\s+', header=None, names=columns, na_values=-999.99)

# create timestamp indices
df['date'] = pd.to_datetime(df[['year', 'month', 'day']])
df = df.set_index('decimal date')

# replace missing values
df['molfrac'] = df['molfrac'].fillna(method='ffill')

df.head()#[Out]#               year  month  day  molfrac  days  1 yr ago  10 yrs ago  \
#[Out]# decimal date                                                          
#[Out]# 1974.3795     1974      5   19   333.34     6       NaN         NaN   
#[Out]# 1974.3986     1974      5   26   332.95     6       NaN         NaN   
#[Out]# 1974.4178     1974      6    2   332.32     5       NaN         NaN   
#[Out]# 1974.4370     1974      6    9   332.18     7       NaN         NaN   
#[Out]# 1974.4562     1974      6   16   332.37     7       NaN         NaN   
#[Out]# 
#[Out]#               since 1880       date  
#[Out]# decimal date                         
#[Out]# 1974.3795          50.36 1974-05-19  
#[Out]# 1974.3986          50.06 1974-05-26  
#[Out]# 1974.4178          49.57 1974-06-02  
#[Out]# 1974.4370          49.63 1974-06-09  
#[Out]# 1974.4562          50.07 1974-06-16  
# Wed, 18 Mar 2020 17:58:34
CO2 = df['molfrac']
CO2.plot()
plt.ylabel('CO2 ppm');# Wed, 18 Mar 2020 17:58:35
from sklearn.base import BaseEstimator, TransformerMixin

class IndexSelector(BaseEstimator, TransformerMixin):
    def __init__(self):
        """Return indices of a data frame for use in other estimators."""
        pass
    
    def fit(self, df, y=None):
        return self
    
    def transform(self, df):
        indices = df.index
        return indices.values.reshape(-1, 1)# Wed, 18 Mar 2020 17:58:35
def ts_train_test_split(df, cutoff, target):
    """Perform a train/test split on a data frame based on a cutoff date."""
    
    ind = df.index < cutoff
    
    df_train = df.loc[ind]
    df_test = df.loc[~ind]
    y_train = df.loc[ind, target]
    y_test = df.loc[~ind, target]
    
    return df_train, df_test, y_train, y_test

def plot_results(df, y_pred):
    """Plot predicted results and residuals."""
    
    CO2.plot();
    plt.plot(list(df.index), y_pred, '-r');
    plt.xlabel('year')
    plt.ylabel('CO2 ppm')
    plt.legend(['true', 'predicted']);
    plt.show();

    plt.plot(resd)
    plt.xlabel('year')
    plt.ylabel('residual')# Wed, 18 Mar 2020 17:58:35
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures

# perform train/test split
cutoff = 2010
df_train, df_test, y_train, y_test = ts_train_test_split(df, cutoff, 'molfrac')

# construct and train pipeline
time = IndexSelector()
poly = PolynomialFeatures(degree=2)
lr = LinearRegression()
pipe = Pipeline([('indices', time),
                 ('drift', poly),
                 ('regressor', lr)])
pipe.fit(df_train, y_train)

# make predictions
y_pred = pipe.predict(df)
resd = CO2 - y_pred
print("Test set R^2: {:g}".format(pipe.score(df_test, y_test)))
plot_results(df, y_pred)# Wed, 18 Mar 2020 17:58:35
from scipy import fftpack

def fft_plot(a=1, b=1, c=1, fourier=True):
    np.random.seed(0)
    N = 100
    t_end = 4
    t = np.linspace(0, t_end, N)
    
    y = a*np.cos(2*np.pi*t) + b*np.sin(4*2*np.pi*t) + c*np.cos(8*2*np.pi*t) + 0.2*np.random.randn(N)
    Y = fftpack.fft(y)
    f = np.linspace(0, N, N)/t_end
    
    if fourier:
        plt.subplot(211)
        plt.plot(t, y)
        plt.xlim([0, 4])
        plt.ylim([-4, 4])
        plt.xlabel('time')
        
        plt.subplot(212)
        plt.plot(f, np.abs(Y)/len(Y))
        plt.ylim([0, 2])
        plt.xlabel('number of cyles in full window')
        plt.tight_layout()
    else:
        plt.plot(t, y)
        plt.xlim([0, 4])
        plt.ylim([-4, 4])
        plt.xlabel('time')

fft_plot(a=1, b=1, c=1, fourier=False);# Wed, 18 Mar 2020 17:58:35
from ipywidgets import interact

interact(fft_plot, a=(0, 4, 0.1), b=(0, 4, 0.1), c=(0, 4, 0.1));# Wed, 18 Mar 2020 17:58:36
from ipywidgets import FloatSlider

def plot_alias(f=0.2, blue=True, green=True):
    t = np.linspace(0, 10, 500)
    t_sampled = np.arange(0, 11)
    
    if blue:
        plt.plot(t, np.sin(2*np.pi*f*t), 'b')
    if green:
        plt.plot(t, -np.sin(2*np.pi*(1-f)*t), 'g')
        
    l, m, b = plt.stem(t_sampled, 
                       np.sin(2*np.pi*f*t_sampled), 
                       linefmt='r', 
                       markerfmt='ro',
                       use_line_collection=True)
    plt.setp(b, visible=False)
    plt.ylim(-2, 2)
    plt.xticks(t_sampled)
    plt.legend(["f={}".format(f), "f={}".format(1-f), "sampled signal"])

interact(plot_alias, f=FloatSlider(min=0, max=1.0, step=0.05, value=0.05, description='$f$'));# Wed, 18 Mar 2020 17:58:36
Y = fftpack.fft(resd-resd.mean())
t_span = CO2.index[-1] - CO2.index[0]
f = np.linspace(0, len(Y), len(Y))/t_span

plt.plot(f[:len(Y)//2], np.abs(Y[:len(Y)//2])/len(Y));
plt.xlabel('frequency (1/yr)')
plt.ylabel('amplitude');# Wed, 18 Mar 2020 17:58:37
plt.plot(f[:200], np.abs(Y)[:200]);
plt.xlabel('frequency (1/yr)')
plt.ylabel('amplitude');# Wed, 18 Mar 2020 17:58:37
from sklearn.base import BaseEstimator, TransformerMixin

class FourierComponents(BaseEstimator, TransformerMixin):
    def __init__(self, freqs):
        """Create features based on sin(2*pi*f*t) and cos(2*pi*f*t)."""
        self.freqs = freqs
    
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        Xt = np.zeros((X.shape[0], 2*len(self.freqs)))
        
        for i, f in enumerate(self.freqs):

            Xt[:, 2*i]= np.cos(2*np.pi*f*X).reshape(-1)
            Xt[:, 2*i + 1] = np.sin(2*np.pi*f*X).reshape(-1)
    
        return Xt# Wed, 18 Mar 2020 17:58:37
from sklearn.pipeline import FeatureUnion

# construct and train pipeline
fourier = FourierComponents([1, 2]) # annual and biannual frequencies
union = FeatureUnion([('drift', poly), ('fourier', fourier)])
baseline = Pipeline([('indices', time),
                 ('union', union),
                 ('regressor', lr)])
baseline.fit(df_train, y_train)

# make predictions
y_pred = baseline.predict(df)
resd = CO2 - y_pred
print("Test set R^2: {:g}".format(baseline.score(df_test, y_test)))
plot_results(df, y_pred)# Wed, 18 Mar 2020 17:58:37
from pandas.plotting import autocorrelation_plot

autocorrelation_plot(resd)
plt.xlabel('Lag (weeks)')
plt.xlim([0, 1000]);# Wed, 18 Mar 2020 17:58:38
def plot_rolling_window(window=10):
    series = pd.Series(resd, index=df.index)

    rolling_window = series.rolling(window=window).mean()
    series.plot(alpha=0.5)
    rolling_window.plot(linewidth=2, color='k')
    plt.title('rolling window')
    plt.xlabel('year')
    plt.ylabel('moving average')
    
interact(plot_rolling_window, window=(1, 200, 1));# Wed, 18 Mar 2020 17:58:38
def plot_exponential_weighted(half_life=100):
    series = pd.Series(resd, index=df.index)
    exponential_weighted = series.ewm(halflife=half_life).mean()
    
    series.plot(alpha=0.5)
    exponential_weighted.plot(linewidth=2, color='k')
    plt.title('exponential weighted')
    plt.xlabel('year')
    plt.ylabel('moving average')

half_life_slider = FloatSlider(min=1, max=100, step=0.1, value=10, description="half-life")
interact(plot_exponential_weighted, half_life=half_life_slider);# Wed, 18 Mar 2020 17:58:38
class ResidualFeatures(BaseEstimator, TransformerMixin):
    def __init__(self, window=100):
        """Generate features based on window statistics of past noise/residuals."""
        self.window = window
        
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        df = pd.DataFrame()
        df['residual'] = pd.Series(X, index=X.index)
        df['prior'] = df['residual'].shift(1)
        df['mean'] = df['residual'].rolling(window=self.window).mean()
        df['diff'] = df['residual'].diff().rolling(window=self.window).mean()
        df = df.fillna(method='bfill')
        
        return df# Wed, 18 Mar 2020 17:58:38
from sklearn.metrics import r2_score

# create and train residual model
resd_train = y_train - baseline.predict(df_train)
residual_feats = ResidualFeatures(window=100)
residual_model = Pipeline([('residual_features', residual_feats), ('regressor', LinearRegression())])
residual_model.fit(resd_train.iloc[:-20], resd_train.shift(-20).dropna())

# evaluate model
resd_pred = residual_model.predict(resd) # prediction for all time steps
resd_pred = pd.Series(resd_pred, index=df.index)
resd_pred = resd_pred.shift(20).dropna() # shift predicted values to matching time step
resd_pred_test = resd_pred.loc[resd_pred.index > 2010] # evaluate only on 2010 values
print("Residual test set R^2: {:g}".format(r2_score(resd.loc[resd.index > 2010], resd_pred_test)))# Wed, 18 Mar 2020 17:58:38
from sklearn.base import RegressorMixin

class FullModel(BaseEstimator, RegressorMixin):
    def __init__(self, baseline, residual_model, steps=20):
        """Combine a baseline and residual model to predict any number of steps in the future."""
        
        self.baseline = baseline
        self.residual_model = residual_model
        self.steps = steps
        
    def fit(self, X, y):
        self.baseline.fit(X, y)
        resd = y - self.baseline.predict(X)
        self.residual_model.fit(resd.iloc[:-self.steps], resd.shift(-self.steps).dropna())
                
        return self
    
    def predict(self, X):
        y_b = pd.Series(self.baseline.predict(X), index=X.index)
        resd = X['molfrac'] - y_b
        resd_pred = pd.Series(self.residual_model.predict(resd), index=X.index)
        resd_pred = resd_pred.shift(self.steps)
        y_pred = y_b + resd_pred
        
        return y_pred
    
# construct and train full model
full_model = FullModel(baseline, residual_model, steps=20)
full_model.fit(df_train, y_train)

# make predictions
y_pred = full_model.predict(df)
resd = CO2 - y_pred
ind = resd.index > 2010
print("Test set R^2: {:g}".format(r2_score(CO2.loc[ind], y_pred.loc[ind])))
plot_results(df, y_pred)# Wed, 18 Mar 2020 17:58:39
from scipy.stats import norm

mu = resd.mean()
sigma = resd.std(ddof=1)
dist = norm(mu, sigma)
x = np.linspace(-2, 2, 100)
f = dist.pdf(x)

resd.hist(bins=40, density=True)
plt.plot(x, f, '-r', linewidth=2);# Wed, 18 Mar 2020 17:58:39
autocorrelation_plot(resd.dropna())
plt.xlim([0, 100]);# Wed, 18 Mar 2020 17:58:39
type(df_train.date.to_numpy())#[Out]# numpy.ndarray
# Wed, 18 Mar 2020 17:58:39
from statsmodels.tsa.ar_model import AR

# create and fit AR model
lag = 200
resd_train = y_train - baseline.predict(df_train)
ar = AR(resd_train.values, dates=df_train['date'], freq='W')
ar = ar.fit(maxlag=lag)
resd_ar_train_pred = ar.predict(start=lag, end=len(df_train)-1)

# plot training set results
plt.plot(list(df_train.index), y_train - baseline.predict(df_train), alpha=0.5)
plt.plot(list(df_train.index[lag:]), resd_ar_train_pred, 'r')
plt.xlabel('year');
plt.ylabel('residual')
plt.legend(['true', 'predicted'])
plt.show();

# plot 20 step forecast of test set
steps = 20
resd_ar_test_pred = ar.predict(start=len(df_train), end=len(df_train) + steps - 1)
plt.plot(range(1, steps + 1), y_test.iloc[:steps] - baseline.predict(df_test.iloc[:steps]))
plt.plot(range(1, steps + 1), resd_ar_test_pred)
plt.xlabel('step')
plt.ylabel('residual')
plt.legend(['true', 'predicted']);# Wed, 18 Mar 2020 17:58:40
import pickle
from statsmodels.tsa.arima_model import ARIMA

# arima = ARIMA(resd_train.values, order=(20, 1, 5), dates=df_train['date'], freq='W')
# arima = arima.fit()

# load pretrained model
with open('data/arima_model.pkl', 'rb') as f:
    arima = pickle.load(f)

# plot 20 step forecast of test set
steps = 20
resd_arima_test_pred, _, _ = arima.forecast(steps)
plt.plot(range(1, steps + 1), resd_arima_test_pred)
plt.xlabel('step')
plt.ylabel('residual');# Wed, 18 Mar 2020 17:58:51
%logstop
%logstart -ortq ~/.logs/ML_Time_Series.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_Time_Series.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
# Wed, 18 Mar 2020 17:58:51
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd# Wed, 18 Mar 2020 17:58:51
from sklearn.linear_model import Ridge
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit

regressor = Ridge()
param_grid = {"alpha": np.logspace(-2, 2, 100)}
ts_cv = TimeSeriesSplit(5) # 5-fold forward chaining
grid_search = GridSearchCV(regressor, param_grid, cv=ts_cv, n_jobs=2)# Wed, 18 Mar 2020 17:58:51
from ipywidgets import interact, FloatSlider

def plot_signal(rho=0):
    n = 1000
    np.random.seed(0)

    eps = np.random.randn(n)
    y = np.zeros(n)
    y[0] = eps[0]
    var = np.zeros(n)
    
    for i in range(1, n):
        y[i] = rho*y[i-1] + eps[i]
        var[i] = y[:i].var()

    plt.subplot(211)
    plt.plot(y)
    plt.ylabel('y')

    plt.subplot(212)
    plt.plot(var)
    plt.ylabel('$\sigma_y$')    
    plt.plot(var)

interact(plot_signal, rho=FloatSlider(min=0, max=1, value=0, step=0.01, description='$\\rho$'));# Wed, 18 Mar 2020 17:58:52
# load data set
columns = ['year', 'month', 'day', 'decimal date', 'molfrac', 'days', '1 yr ago', '10 yrs ago', 'since 1880']
df = pd.read_csv('data/co2_weekly_mlo.txt', sep='\s+', header=None, names=columns, na_values=-999.99)

# create timestamp indices
df['date'] = pd.to_datetime(df[['year', 'month', 'day']])
df = df.set_index('decimal date')

# replace missing values
df['molfrac'] = df['molfrac'].fillna(method='ffill')

df.head()#[Out]#               year  month  day  molfrac  days  1 yr ago  10 yrs ago  \
#[Out]# decimal date                                                          
#[Out]# 1974.3795     1974      5   19   333.34     6       NaN         NaN   
#[Out]# 1974.3986     1974      5   26   332.95     6       NaN         NaN   
#[Out]# 1974.4178     1974      6    2   332.32     5       NaN         NaN   
#[Out]# 1974.4370     1974      6    9   332.18     7       NaN         NaN   
#[Out]# 1974.4562     1974      6   16   332.37     7       NaN         NaN   
#[Out]# 
#[Out]#               since 1880       date  
#[Out]# decimal date                         
#[Out]# 1974.3795          50.36 1974-05-19  
#[Out]# 1974.3986          50.06 1974-05-26  
#[Out]# 1974.4178          49.57 1974-06-02  
#[Out]# 1974.4370          49.63 1974-06-09  
#[Out]# 1974.4562          50.07 1974-06-16  
# Wed, 18 Mar 2020 17:58:52
CO2 = df['molfrac']
CO2.plot()
plt.ylabel('CO2 ppm');# Wed, 18 Mar 2020 17:58:52
from sklearn.base import BaseEstimator, TransformerMixin

class IndexSelector(BaseEstimator, TransformerMixin):
    def __init__(self):
        """Return indices of a data frame for use in other estimators."""
        pass
    
    def fit(self, df, y=None):
        return self
    
    def transform(self, df):
        indices = df.index
        return indices.values.reshape(-1, 1)# Wed, 18 Mar 2020 17:58:52
def ts_train_test_split(df, cutoff, target):
    """Perform a train/test split on a data frame based on a cutoff date."""
    
    ind = df.index < cutoff
    
    df_train = df.loc[ind]
    df_test = df.loc[~ind]
    y_train = df.loc[ind, target]
    y_test = df.loc[~ind, target]
    
    return df_train, df_test, y_train, y_test

def plot_results(df, y_pred):
    """Plot predicted results and residuals."""
    
    CO2.plot();
    plt.plot(list(df.index), y_pred, '-r');
    plt.xlabel('year')
    plt.ylabel('CO2 ppm')
    plt.legend(['true', 'predicted']);
    plt.show();

    plt.plot(resd)
    plt.xlabel('year')
    plt.ylabel('residual')# Wed, 18 Mar 2020 17:58:52
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures

# perform train/test split
cutoff = 2010
df_train, df_test, y_train, y_test = ts_train_test_split(df, cutoff, 'molfrac')

# construct and train pipeline
time = IndexSelector()
poly = PolynomialFeatures(degree=2)
lr = LinearRegression()
pipe = Pipeline([('indices', time),
                 ('drift', poly),
                 ('regressor', lr)])
pipe.fit(df_train, y_train)

# make predictions
y_pred = pipe.predict(df)
resd = CO2 - y_pred
print("Test set R^2: {:g}".format(pipe.score(df_test, y_test)))
plot_results(df, y_pred)# Wed, 18 Mar 2020 17:58:53
from scipy import fftpack

def fft_plot(a=1, b=1, c=1, fourier=True):
    np.random.seed(0)
    N = 100
    t_end = 4
    t = np.linspace(0, t_end, N)
    
    y = a*np.cos(2*np.pi*t) + b*np.sin(4*2*np.pi*t) + c*np.cos(8*2*np.pi*t) + 0.2*np.random.randn(N)
    Y = fftpack.fft(y)
    f = np.linspace(0, N, N)/t_end
    
    if fourier:
        plt.subplot(211)
        plt.plot(t, y)
        plt.xlim([0, 4])
        plt.ylim([-4, 4])
        plt.xlabel('time')
        
        plt.subplot(212)
        plt.plot(f, np.abs(Y)/len(Y))
        plt.ylim([0, 2])
        plt.xlabel('number of cyles in full window')
        plt.tight_layout()
    else:
        plt.plot(t, y)
        plt.xlim([0, 4])
        plt.ylim([-4, 4])
        plt.xlabel('time')

fft_plot(a=1, b=1, c=1, fourier=False);# Wed, 18 Mar 2020 17:58:53
from ipywidgets import interact

interact(fft_plot, a=(0, 4, 0.1), b=(0, 4, 0.1), c=(0, 4, 0.1));# Wed, 18 Mar 2020 17:58:54
from ipywidgets import FloatSlider

def plot_alias(f=0.2, blue=True, green=True):
    t = np.linspace(0, 10, 500)
    t_sampled = np.arange(0, 11)
    
    if blue:
        plt.plot(t, np.sin(2*np.pi*f*t), 'b')
    if green:
        plt.plot(t, -np.sin(2*np.pi*(1-f)*t), 'g')
        
    l, m, b = plt.stem(t_sampled, 
                       np.sin(2*np.pi*f*t_sampled), 
                       linefmt='r', 
                       markerfmt='ro',
                       use_line_collection=True)
    plt.setp(b, visible=False)
    plt.ylim(-2, 2)
    plt.xticks(t_sampled)
    plt.legend(["f={}".format(f), "f={}".format(1-f), "sampled signal"])

interact(plot_alias, f=FloatSlider(min=0, max=1.0, step=0.05, value=0.05, description='$f$'));# Wed, 18 Mar 2020 17:58:54
Y = fftpack.fft(resd-resd.mean())
t_span = CO2.index[-1] - CO2.index[0]
f = np.linspace(0, len(Y), len(Y))/t_span

plt.plot(f[:len(Y)//2], np.abs(Y[:len(Y)//2])/len(Y));
plt.xlabel('frequency (1/yr)')
plt.ylabel('amplitude');# Wed, 18 Mar 2020 17:58:54
plt.plot(f[:200], np.abs(Y)[:200]);
plt.xlabel('frequency (1/yr)')
plt.ylabel('amplitude');# Wed, 18 Mar 2020 17:58:54
from sklearn.base import BaseEstimator, TransformerMixin

class FourierComponents(BaseEstimator, TransformerMixin):
    def __init__(self, freqs):
        """Create features based on sin(2*pi*f*t) and cos(2*pi*f*t)."""
        self.freqs = freqs
    
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        Xt = np.zeros((X.shape[0], 2*len(self.freqs)))
        
        for i, f in enumerate(self.freqs):

            Xt[:, 2*i]= np.cos(2*np.pi*f*X).reshape(-1)
            Xt[:, 2*i + 1] = np.sin(2*np.pi*f*X).reshape(-1)
    
        return Xt# Wed, 18 Mar 2020 17:58:54
from sklearn.pipeline import FeatureUnion

# construct and train pipeline
fourier = FourierComponents([1, 2]) # annual and biannual frequencies
union = FeatureUnion([('drift', poly), ('fourier', fourier)])
baseline = Pipeline([('indices', time),
                 ('union', union),
                 ('regressor', lr)])
baseline.fit(df_train, y_train)

# make predictions
y_pred = baseline.predict(df)
resd = CO2 - y_pred
print("Test set R^2: {:g}".format(baseline.score(df_test, y_test)))
plot_results(df, y_pred)# Wed, 18 Mar 2020 17:58:55
from pandas.plotting import autocorrelation_plot

autocorrelation_plot(resd)
plt.xlabel('Lag (weeks)')
plt.xlim([0, 1000]);# Wed, 18 Mar 2020 17:58:55
def plot_rolling_window(window=10):
    series = pd.Series(resd, index=df.index)

    rolling_window = series.rolling(window=window).mean()
    series.plot(alpha=0.5)
    rolling_window.plot(linewidth=2, color='k')
    plt.title('rolling window')
    plt.xlabel('year')
    plt.ylabel('moving average')
    
interact(plot_rolling_window, window=(1, 200, 1));# Wed, 18 Mar 2020 17:58:56
def plot_exponential_weighted(half_life=100):
    series = pd.Series(resd, index=df.index)
    exponential_weighted = series.ewm(halflife=half_life).mean()
    
    series.plot(alpha=0.5)
    exponential_weighted.plot(linewidth=2, color='k')
    plt.title('exponential weighted')
    plt.xlabel('year')
    plt.ylabel('moving average')

half_life_slider = FloatSlider(min=1, max=100, step=0.1, value=10, description="half-life")
interact(plot_exponential_weighted, half_life=half_life_slider);# Wed, 18 Mar 2020 17:58:56
class ResidualFeatures(BaseEstimator, TransformerMixin):
    def __init__(self, window=100):
        """Generate features based on window statistics of past noise/residuals."""
        self.window = window
        
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        df = pd.DataFrame()
        df['residual'] = pd.Series(X, index=X.index)
        df['prior'] = df['residual'].shift(1)
        df['mean'] = df['residual'].rolling(window=self.window).mean()
        df['diff'] = df['residual'].diff().rolling(window=self.window).mean()
        df = df.fillna(method='bfill')
        
        return df# Wed, 18 Mar 2020 17:58:56
from sklearn.metrics import r2_score

# create and train residual model
resd_train = y_train - baseline.predict(df_train)
residual_feats = ResidualFeatures(window=100)
residual_model = Pipeline([('residual_features', residual_feats), ('regressor', LinearRegression())])
residual_model.fit(resd_train.iloc[:-20], resd_train.shift(-20).dropna())

# evaluate model
resd_pred = residual_model.predict(resd) # prediction for all time steps
resd_pred = pd.Series(resd_pred, index=df.index)
resd_pred = resd_pred.shift(20).dropna() # shift predicted values to matching time step
resd_pred_test = resd_pred.loc[resd_pred.index > 2010] # evaluate only on 2010 values
print("Residual test set R^2: {:g}".format(r2_score(resd.loc[resd.index > 2010], resd_pred_test)))# Wed, 18 Mar 2020 17:58:56
from sklearn.base import RegressorMixin

class FullModel(BaseEstimator, RegressorMixin):
    def __init__(self, baseline, residual_model, steps=20):
        """Combine a baseline and residual model to predict any number of steps in the future."""
        
        self.baseline = baseline
        self.residual_model = residual_model
        self.steps = steps
        
    def fit(self, X, y):
        self.baseline.fit(X, y)
        resd = y - self.baseline.predict(X)
        self.residual_model.fit(resd.iloc[:-self.steps], resd.shift(-self.steps).dropna())
                
        return self
    
    def predict(self, X):
        y_b = pd.Series(self.baseline.predict(X), index=X.index)
        resd = X['molfrac'] - y_b
        resd_pred = pd.Series(self.residual_model.predict(resd), index=X.index)
        resd_pred = resd_pred.shift(self.steps)
        y_pred = y_b + resd_pred
        
        return y_pred
    
# construct and train full model
full_model = FullModel(baseline, residual_model, steps=20)
full_model.fit(df_train, y_train)

# make predictions
y_pred = full_model.predict(df)
resd = CO2 - y_pred
ind = resd.index > 2010
print("Test set R^2: {:g}".format(r2_score(CO2.loc[ind], y_pred.loc[ind])))
plot_results(df, y_pred)# Wed, 18 Mar 2020 17:58:56
from scipy.stats import norm

mu = resd.mean()
sigma = resd.std(ddof=1)
dist = norm(mu, sigma)
x = np.linspace(-2, 2, 100)
f = dist.pdf(x)

resd.hist(bins=40, density=True)
plt.plot(x, f, '-r', linewidth=2);# Wed, 18 Mar 2020 17:58:57
autocorrelation_plot(resd.dropna())
plt.xlim([0, 100]);# Wed, 18 Mar 2020 17:58:57
type(df_train.date.to_numpy())#[Out]# numpy.ndarray
# Wed, 18 Mar 2020 17:58:57
from statsmodels.tsa.ar_model import AR

# create and fit AR model
lag = 200
resd_train = y_train - baseline.predict(df_train)
ar = AR(resd_train.values, dates=df_train['date'], freq='W')
ar = ar.fit(maxlag=lag)
resd_ar_train_pred = ar.predict(start=lag, end=len(df_train)-1)

# plot training set results
plt.plot(list(df_train.index), y_train - baseline.predict(df_train), alpha=0.5)
plt.plot(list(df_train.index[lag:]), resd_ar_train_pred, 'r')
plt.xlabel('year');
plt.ylabel('residual')
plt.legend(['true', 'predicted'])
plt.show();

# plot 20 step forecast of test set
steps = 20
resd_ar_test_pred = ar.predict(start=len(df_train), end=len(df_train) + steps - 1)
plt.plot(range(1, steps + 1), y_test.iloc[:steps] - baseline.predict(df_test.iloc[:steps]))
plt.plot(range(1, steps + 1), resd_ar_test_pred)
plt.xlabel('step')
plt.ylabel('residual')
plt.legend(['true', 'predicted']);# Wed, 18 Mar 2020 17:58:58
import pickle
from statsmodels.tsa.arima_model import ARIMA

# arima = ARIMA(resd_train.values, order=(20, 1, 5), dates=df_train['date'], freq='W')
# arima = arima.fit()

# load pretrained model
with open('data/arima_model.pkl', 'rb') as f:
    arima = pickle.load(f)

# plot 20 step forecast of test set
steps = 20
resd_arima_test_pred, _, _ = arima.forecast(steps)
plt.plot(range(1, steps + 1), resd_arima_test_pred)
plt.xlabel('step')
plt.ylabel('residual');# Wed, 18 Mar 2020 17:58:58
%logstop
%logstart -ortq ~/.logs/ML_Time_Series.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_Time_Series.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
%logstop
%logstart -ortq ~/.logs/ML_Time_Series.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit

regressor = Ridge()
param_grid = {"alpha": np.logspace(-2, 2, 100)}
ts_cv = TimeSeriesSplit(5) # 5-fold forward chaining
grid_search = GridSearchCV(regressor, param_grid, cv=ts_cv, n_jobs=2)
from ipywidgets import interact, FloatSlider

def plot_signal(rho=0):
    n = 1000
    np.random.seed(0)

    eps = np.random.randn(n)
    y = np.zeros(n)
    y[0] = eps[0]
    var = np.zeros(n)
    
    for i in range(1, n):
        y[i] = rho*y[i-1] + eps[i]
        var[i] = y[:i].var()

    plt.subplot(211)
    plt.plot(y)
    plt.ylabel('y')

    plt.subplot(212)
    plt.plot(var)
    plt.ylabel('$\sigma_y$')    
    plt.plot(var)

interact(plot_signal, rho=FloatSlider(min=0, max=1, value=0, step=0.01, description='$\\rho$'));
# load data set
columns = ['year', 'month', 'day', 'decimal date', 'molfrac', 'days', '1 yr ago', '10 yrs ago', 'since 1880']
df = pd.read_csv('data/co2_weekly_mlo.txt', sep='\s+', header=None, names=columns, na_values=-999.99)

# create timestamp indices
df['date'] = pd.to_datetime(df[['year', 'month', 'day']])
df = df.set_index('decimal date')

# replace missing values
df['molfrac'] = df['molfrac'].fillna(method='ffill')

df.head()
#[Out]#               year  month  day  molfrac  days  1 yr ago  10 yrs ago  \
#[Out]# decimal date                                                          
#[Out]# 1974.3795     1974      5   19   333.34     6       NaN         NaN   
#[Out]# 1974.3986     1974      5   26   332.95     6       NaN         NaN   
#[Out]# 1974.4178     1974      6    2   332.32     5       NaN         NaN   
#[Out]# 1974.4370     1974      6    9   332.18     7       NaN         NaN   
#[Out]# 1974.4562     1974      6   16   332.37     7       NaN         NaN   
#[Out]# 
#[Out]#               since 1880       date  
#[Out]# decimal date                         
#[Out]# 1974.3795          50.36 1974-05-19  
#[Out]# 1974.3986          50.06 1974-05-26  
#[Out]# 1974.4178          49.57 1974-06-02  
#[Out]# 1974.4370          49.63 1974-06-09  
#[Out]# 1974.4562          50.07 1974-06-16  
CO2 = df['molfrac']
CO2.plot()
plt.ylabel('CO2 ppm');
from sklearn.base import BaseEstimator, TransformerMixin

class IndexSelector(BaseEstimator, TransformerMixin):
    def __init__(self):
        """Return indices of a data frame for use in other estimators."""
        pass
    
    def fit(self, df, y=None):
        return self
    
    def transform(self, df):
        indices = df.index
        return indices.values.reshape(-1, 1)
def ts_train_test_split(df, cutoff, target):
    """Perform a train/test split on a data frame based on a cutoff date."""
    
    ind = df.index < cutoff
    
    df_train = df.loc[ind]
    df_test = df.loc[~ind]
    y_train = df.loc[ind, target]
    y_test = df.loc[~ind, target]
    
    return df_train, df_test, y_train, y_test

def plot_results(df, y_pred):
    """Plot predicted results and residuals."""
    
    CO2.plot();
    plt.plot(list(df.index), y_pred, '-r');
    plt.xlabel('year')
    plt.ylabel('CO2 ppm')
    plt.legend(['true', 'predicted']);
    plt.show();

    plt.plot(resd)
    plt.xlabel('year')
    plt.ylabel('residual')
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures

# perform train/test split
cutoff = 2010
df_train, df_test, y_train, y_test = ts_train_test_split(df, cutoff, 'molfrac')

# construct and train pipeline
time = IndexSelector()
poly = PolynomialFeatures(degree=2)
lr = LinearRegression()
pipe = Pipeline([('indices', time),
                 ('drift', poly),
                 ('regressor', lr)])
pipe.fit(df_train, y_train)

# make predictions
y_pred = pipe.predict(df)
resd = CO2 - y_pred
print("Test set R^2: {:g}".format(pipe.score(df_test, y_test)))
plot_results(df, y_pred)
from scipy import fftpack

def fft_plot(a=1, b=1, c=1, fourier=True):
    np.random.seed(0)
    N = 100
    t_end = 4
    t = np.linspace(0, t_end, N)
    
    y = a*np.cos(2*np.pi*t) + b*np.sin(4*2*np.pi*t) + c*np.cos(8*2*np.pi*t) + 0.2*np.random.randn(N)
    Y = fftpack.fft(y)
    f = np.linspace(0, N, N)/t_end
    
    if fourier:
        plt.subplot(211)
        plt.plot(t, y)
        plt.xlim([0, 4])
        plt.ylim([-4, 4])
        plt.xlabel('time')
        
        plt.subplot(212)
        plt.plot(f, np.abs(Y)/len(Y))
        plt.ylim([0, 2])
        plt.xlabel('number of cyles in full window')
        plt.tight_layout()
    else:
        plt.plot(t, y)
        plt.xlim([0, 4])
        plt.ylim([-4, 4])
        plt.xlabel('time')

fft_plot(a=1, b=1, c=1, fourier=False);
from ipywidgets import interact

interact(fft_plot, a=(0, 4, 0.1), b=(0, 4, 0.1), c=(0, 4, 0.1));
from ipywidgets import FloatSlider

def plot_alias(f=0.2, blue=True, green=True):
    t = np.linspace(0, 10, 500)
    t_sampled = np.arange(0, 11)
    
    if blue:
        plt.plot(t, np.sin(2*np.pi*f*t), 'b')
    if green:
        plt.plot(t, -np.sin(2*np.pi*(1-f)*t), 'g')
        
    l, m, b = plt.stem(t_sampled, 
                       np.sin(2*np.pi*f*t_sampled), 
                       linefmt='r', 
                       markerfmt='ro',
                       use_line_collection=True)
    plt.setp(b, visible=False)
    plt.ylim(-2, 2)
    plt.xticks(t_sampled)
    plt.legend(["f={}".format(f), "f={}".format(1-f), "sampled signal"])

interact(plot_alias, f=FloatSlider(min=0, max=1.0, step=0.05, value=0.05, description='$f$'));
Y = fftpack.fft(resd-resd.mean())
t_span = CO2.index[-1] - CO2.index[0]
f = np.linspace(0, len(Y), len(Y))/t_span

plt.plot(f[:len(Y)//2], np.abs(Y[:len(Y)//2])/len(Y));
plt.xlabel('frequency (1/yr)')
plt.ylabel('amplitude');
plt.plot(f[:200], np.abs(Y)[:200]);
plt.xlabel('frequency (1/yr)')
plt.ylabel('amplitude');
from sklearn.base import BaseEstimator, TransformerMixin

class FourierComponents(BaseEstimator, TransformerMixin):
    def __init__(self, freqs):
        """Create features based on sin(2*pi*f*t) and cos(2*pi*f*t)."""
        self.freqs = freqs
    
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        Xt = np.zeros((X.shape[0], 2*len(self.freqs)))
        
        for i, f in enumerate(self.freqs):

            Xt[:, 2*i]= np.cos(2*np.pi*f*X).reshape(-1)
            Xt[:, 2*i + 1] = np.sin(2*np.pi*f*X).reshape(-1)
    
        return Xt
from sklearn.pipeline import FeatureUnion

# construct and train pipeline
fourier = FourierComponents([1, 2]) # annual and biannual frequencies
union = FeatureUnion([('drift', poly), ('fourier', fourier)])
baseline = Pipeline([('indices', time),
                 ('union', union),
                 ('regressor', lr)])
baseline.fit(df_train, y_train)

# make predictions
y_pred = baseline.predict(df)
resd = CO2 - y_pred
print("Test set R^2: {:g}".format(baseline.score(df_test, y_test)))
plot_results(df, y_pred)
from pandas.plotting import autocorrelation_plot

autocorrelation_plot(resd)
plt.xlabel('Lag (weeks)')
plt.xlim([0, 1000]);
def plot_rolling_window(window=10):
    series = pd.Series(resd, index=df.index)

    rolling_window = series.rolling(window=window).mean()
    series.plot(alpha=0.5)
    rolling_window.plot(linewidth=2, color='k')
    plt.title('rolling window')
    plt.xlabel('year')
    plt.ylabel('moving average')
    
interact(plot_rolling_window, window=(1, 200, 1));
def plot_exponential_weighted(half_life=100):
    series = pd.Series(resd, index=df.index)
    exponential_weighted = series.ewm(halflife=half_life).mean()
    
    series.plot(alpha=0.5)
    exponential_weighted.plot(linewidth=2, color='k')
    plt.title('exponential weighted')
    plt.xlabel('year')
    plt.ylabel('moving average')

half_life_slider = FloatSlider(min=1, max=100, step=0.1, value=10, description="half-life")
interact(plot_exponential_weighted, half_life=half_life_slider);
class ResidualFeatures(BaseEstimator, TransformerMixin):
    def __init__(self, window=100):
        """Generate features based on window statistics of past noise/residuals."""
        self.window = window
        
    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        df = pd.DataFrame()
        df['residual'] = pd.Series(X, index=X.index)
        df['prior'] = df['residual'].shift(1)
        df['mean'] = df['residual'].rolling(window=self.window).mean()
        df['diff'] = df['residual'].diff().rolling(window=self.window).mean()
        df = df.fillna(method='bfill')
        
        return df
from sklearn.metrics import r2_score

# create and train residual model
resd_train = y_train - baseline.predict(df_train)
residual_feats = ResidualFeatures(window=100)
residual_model = Pipeline([('residual_features', residual_feats), ('regressor', LinearRegression())])
residual_model.fit(resd_train.iloc[:-20], resd_train.shift(-20).dropna())

# evaluate model
resd_pred = residual_model.predict(resd) # prediction for all time steps
resd_pred = pd.Series(resd_pred, index=df.index)
resd_pred = resd_pred.shift(20).dropna() # shift predicted values to matching time step
resd_pred_test = resd_pred.loc[resd_pred.index > 2010] # evaluate only on 2010 values
print("Residual test set R^2: {:g}".format(r2_score(resd.loc[resd.index > 2010], resd_pred_test)))
from sklearn.base import RegressorMixin

class FullModel(BaseEstimator, RegressorMixin):
    def __init__(self, baseline, residual_model, steps=20):
        """Combine a baseline and residual model to predict any number of steps in the future."""
        
        self.baseline = baseline
        self.residual_model = residual_model
        self.steps = steps
        
    def fit(self, X, y):
        self.baseline.fit(X, y)
        resd = y - self.baseline.predict(X)
        self.residual_model.fit(resd.iloc[:-self.steps], resd.shift(-self.steps).dropna())
                
        return self
    
    def predict(self, X):
        y_b = pd.Series(self.baseline.predict(X), index=X.index)
        resd = X['molfrac'] - y_b
        resd_pred = pd.Series(self.residual_model.predict(resd), index=X.index)
        resd_pred = resd_pred.shift(self.steps)
        y_pred = y_b + resd_pred
        
        return y_pred
    
# construct and train full model
full_model = FullModel(baseline, residual_model, steps=20)
full_model.fit(df_train, y_train)

# make predictions
y_pred = full_model.predict(df)
resd = CO2 - y_pred
ind = resd.index > 2010
print("Test set R^2: {:g}".format(r2_score(CO2.loc[ind], y_pred.loc[ind])))
plot_results(df, y_pred)
from scipy.stats import norm

mu = resd.mean()
sigma = resd.std(ddof=1)
dist = norm(mu, sigma)
x = np.linspace(-2, 2, 100)
f = dist.pdf(x)

resd.hist(bins=40, density=True)
plt.plot(x, f, '-r', linewidth=2);
autocorrelation_plot(resd.dropna())
plt.xlim([0, 100]);
type(df_train.date.to_numpy())
#[Out]# <class 'numpy.ndarray'>
from statsmodels.tsa.ar_model import AR

# create and fit AR model
lag = 200
resd_train = y_train - baseline.predict(df_train)
ar = AR(resd_train.values, dates=df_train['date'], freq='W')
ar = ar.fit(maxlag=lag)
resd_ar_train_pred = ar.predict(start=lag, end=len(df_train)-1)

# plot training set results
plt.plot(list(df_train.index), y_train - baseline.predict(df_train), alpha=0.5)
plt.plot(list(df_train.index[lag:]), resd_ar_train_pred, 'r')
plt.xlabel('year');
plt.ylabel('residual')
plt.legend(['true', 'predicted'])
plt.show();

# plot 20 step forecast of test set
steps = 20
resd_ar_test_pred = ar.predict(start=len(df_train), end=len(df_train) + steps - 1)
plt.plot(range(1, steps + 1), y_test.iloc[:steps] - baseline.predict(df_test.iloc[:steps]))
plt.plot(range(1, steps + 1), resd_ar_test_pred)
plt.xlabel('step')
plt.ylabel('residual')
plt.legend(['true', 'predicted']);
import pickle
from statsmodels.tsa.arima_model import ARIMA

# arima = ARIMA(resd_train.values, order=(20, 1, 5), dates=df_train['date'], freq='W')
# arima = arima.fit()

# load pretrained model
with open('data/arima_model.pkl', 'rb') as f:
    arima = pickle.load(f)

# plot 20 step forecast of test set
steps = 20
resd_arima_test_pred, _, _ = arima.forecast(steps)
plt.plot(range(1, steps + 1), resd_arima_test_pred)
plt.xlabel('step')
plt.ylabel('residual');
