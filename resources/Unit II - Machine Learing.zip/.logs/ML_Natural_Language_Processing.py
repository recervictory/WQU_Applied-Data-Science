# Wed, 18 Mar 2020 18:03:00
%logstop
%logstart -ortq ~/.logs/ML_Natural_Language_Processing.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_Natural_Language_Processing.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
# Wed, 18 Mar 2020 18:03:00
import spacy

# load text processing pipeline
nlp = spacy.load('en')

# nlp accepts a string
doc = nlp("Let's try out spacy. We can easily divide our text into sentences! I've run out of ideas.")

# iterate through each sentence
for sent in doc.sents:
    print(sent)

# index words
print(doc[0])
print(doc[6])# Wed, 18 Mar 2020 18:03:02
doc = nlp("The quick brown fox jumped over the lazy dog. Mr. Peanut wears a top hat.")
tags = set()

# reveal part of speech
for word in doc:
    tags.add(word.tag_)
    print((word.text, word.pos_, word.tag_))

# revealing meaning of tags
print()
for tag in tags:
    print(tag, spacy.explain(tag))# Wed, 18 Mar 2020 18:03:02
import wikipedia

def pages_to_sentences(*pages):
    """Return a list of sentences in Wikipedia articles."""
    sentences = []
    
    for page in pages:
        p = wikipedia.page(page)
        doc = nlp(p.content)
        sentences += [sent.text for sent in doc.sents]
    
    return sentences

animal_sents = pages_to_sentences("Reticulated python", "Ball Python")
language_sents = pages_to_sentences("Python (programming language)")
documents = animal_sents + language_sents

print(language_sents[:5])
print()
print(animal_sents[:5])# Wed, 18 Mar 2020 18:12:57
%logstop
%logstart -ortq ~/.logs/ML_Natural_Language_Processing.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_Natural_Language_Processing.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
# Wed, 18 Mar 2020 18:12:57
import spacy

# load text processing pipeline
nlp = spacy.load('en')

# nlp accepts a string
doc = nlp("Let's try out spacy. We can easily divide our text into sentences! I've run out of ideas.")

# iterate through each sentence
for sent in doc.sents:
    print(sent)

# index words
print(doc[0])
print(doc[6])# Wed, 18 Mar 2020 18:12:58
doc = nlp("The quick brown fox jumped over the lazy dog. Mr. Peanut wears a top hat.")
tags = set()

# reveal part of speech
for word in doc:
    tags.add(word.tag_)
    print((word.text, word.pos_, word.tag_))

# revealing meaning of tags
print()
for tag in tags:
    print(tag, spacy.explain(tag))# Wed, 18 Mar 2020 18:12:58
import wikipedia

def pages_to_sentences(*pages):
    """Return a list of sentences in Wikipedia articles."""
    sentences = []
    
    for page in pages:
        p = wikipedia.page(page)
        doc = nlp(p.content)
        sentences += [sent.text for sent in doc.sents]
    
    return sentences

animal_sents = pages_to_sentences("Reticulated python", "Ball Python")
language_sents = pages_to_sentences("Python (programming language)")
documents = animal_sents + language_sents

print(language_sents[:5])
print()
print(animal_sents[:5])# Wed, 18 Mar 2020 18:13:27
import wikipedia

def pages_to_sentences(*pages):
    """Return a list of sentences in Wikipedia articles."""
    sentences = []
    
    for page in pages:
        p = wikipedia.page(page)
        doc = nlp(p.content)
        sentences += [sent.text for sent in doc.sents]
    
    return sentences

animal_sents = pages_to_sentences("Reticulated python", "Ball Python")
language_sents = pages_to_sentences("Python (programming language)")
documents = animal_sents + language_sents

print(language_sents[:5])
print()
print(animal_sents[:5])# Wed, 18 Mar 2020 18:13:36
%logstop
%logstart -ortq ~/.logs/ML_Natural_Language_Processing.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_Natural_Language_Processing.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
import wikipedia

def pages_to_sentences(*pages):
    """Return a list of sentences in Wikipedia articles."""
    sentences = []
    
    for page in pages:
        p = wikipedia.page(page)
        doc = nlp(p.content)
        sentences += [sent.text for sent in doc.sents]
    
    return sentences

animal_sents = pages_to_sentences("Reticulated python", "Ball Python")
language_sents = pages_to_sentences("Python (programming language)")
documents = animal_sents + language_sents

print(language_sents[:5])
print()
print(animal_sents[:5])
# Wed, 18 Mar 2020 18:13:40
import spacy

# load text processing pipeline
nlp = spacy.load('en')

# nlp accepts a string
doc = nlp("Let's try out spacy. We can easily divide our text into sentences! I've run out of ideas.")

# iterate through each sentence
for sent in doc.sents:
    print(sent)

# index words
print(doc[0])
print(doc[6])# Wed, 18 Mar 2020 18:13:45
doc = nlp("The quick brown fox jumped over the lazy dog. Mr. Peanut wears a top hat.")
tags = set()

# reveal part of speech
for word in doc:
    tags.add(word.tag_)
    print((word.text, word.pos_, word.tag_))

# revealing meaning of tags
print()
for tag in tags:
    print(tag, spacy.explain(tag))# Wed, 18 Mar 2020 18:13:50
import wikipedia

def pages_to_sentences(*pages):
    """Return a list of sentences in Wikipedia articles."""
    sentences = []
    
    for page in pages:
        p = wikipedia.page(page)
        doc = nlp(p.content)
        sentences += [sent.text for sent in doc.sents]
    
    return sentences

animal_sents = pages_to_sentences("Reticulated python", "Ball Python")
language_sents = pages_to_sentences("Python (programming language)")
documents = animal_sents + language_sents

print(language_sents[:5])
print()
print(animal_sents[:5])# Wed, 18 Mar 2020 18:14:00
from sklearn.feature_extraction.text import CountVectorizer

bag_of_words = CountVectorizer()
bag_of_words.fit(documents)
word_counts = bag_of_words.transform(documents)

print(word_counts)
word_counts#[Out]# <606x2762 sparse matrix of type '<class 'numpy.int64'>'
#[Out]# 	with 8815 stored elements in Compressed Sparse Row format>
# Wed, 18 Mar 2020 18:14:05
# get word counts
counts_animal = bag_of_words.transform(animal_sents)
counts_language = bag_of_words.transform(language_sents)

# index for "programming"
ind_programming = bag_of_words.vocabulary_['programming']

# total counts across all documents
print(counts_animal.sum(axis=0)[0, ind_programming])
print(counts_language.sum(axis=0)[0, ind_programming])# Wed, 18 Mar 2020 18:14:07
print(hash("hi!"))
print(hash("python"))
print(hash("Pyton"))
print(hash("hi!"))# Wed, 18 Mar 2020 18:14:09
from sklearn.feature_extraction.text import HashingVectorizer

hashing_bag_of_words = HashingVectorizer(norm=None) # by default, it normalizes the vectors
hashing_bag_of_words.fit(documents)
hashing_bag_of_words.transform(documents)#[Out]# <606x1048576 sparse matrix of type '<class 'numpy.float64'>'
#[Out]# 	with 8815 stored elements in Compressed Sparse Row format>
# Wed, 18 Mar 2020 18:14:11
import time

t_0 = time.time()
CountVectorizer().fit_transform(documents)
t_elapsed = time.time() - t_0
print("Fitting time for CountVectorizer: {}".format(t_elapsed))

t_0 = time.time()
HashingVectorizer(norm=None).fit_transform(documents)
t_elapsed = time.time() - t_0
print("Fitting time for HashingVectorizer: {}".format(t_elapsed))# Wed, 18 Mar 2020 18:14:13
from sklearn.feature_extraction.text import TfidfTransformer

tfidf = TfidfTransformer()
tfidf_weights = tfidf.fit_transform(word_counts)
print(tfidf_weights)# Wed, 18 Mar 2020 18:14:15
top_idf_indices = tfidf.idf_.argsort()[:-20:-1]
ind_to_word = bag_of_words.get_feature_names()

for ind in top_idf_indices:
    print(tfidf.idf_[ind], ind_to_word[ind])# Wed, 18 Mar 2020 18:14:18
from spacy.lang.en import STOP_WORDS

print(type(STOP_WORDS))
STOP_WORDS_python = STOP_WORDS.union({"python"})
STOP_WORDS_python#[Out]# {'a',
#[Out]#  'about',
#[Out]#  'above',
#[Out]#  'across',
#[Out]#  'after',
#[Out]#  'afterwards',
#[Out]#  'again',
#[Out]#  'against',
#[Out]#  'all',
#[Out]#  'almost',
#[Out]#  'alone',
#[Out]#  'along',
#[Out]#  'already',
#[Out]#  'also',
#[Out]#  'although',
#[Out]#  'always',
#[Out]#  'am',
#[Out]#  'among',
#[Out]#  'amongst',
#[Out]#  'amount',
#[Out]#  'an',
#[Out]#  'and',
#[Out]#  'another',
#[Out]#  'any',
#[Out]#  'anyhow',
#[Out]#  'anyone',
#[Out]#  'anything',
#[Out]#  'anyway',
#[Out]#  'anywhere',
#[Out]#  'are',
#[Out]#  'around',
#[Out]#  'as',
#[Out]#  'at',
#[Out]#  'back',
#[Out]#  'be',
#[Out]#  'became',
#[Out]#  'because',
#[Out]#  'become',
#[Out]#  'becomes',
#[Out]#  'becoming',
#[Out]#  'been',
#[Out]#  'before',
#[Out]#  'beforehand',
#[Out]#  'behind',
#[Out]#  'being',
#[Out]#  'below',
#[Out]#  'beside',
#[Out]#  'besides',
#[Out]#  'between',
#[Out]#  'beyond',
#[Out]#  'both',
#[Out]#  'bottom',
#[Out]#  'but',
#[Out]#  'by',
#[Out]#  'ca',
#[Out]#  'call',
#[Out]#  'can',
#[Out]#  'cannot',
#[Out]#  'could',
#[Out]#  'did',
#[Out]#  'do',
#[Out]#  'does',
#[Out]#  'doing',
#[Out]#  'done',
#[Out]#  'down',
#[Out]#  'due',
#[Out]#  'during',
#[Out]#  'each',
#[Out]#  'eight',
#[Out]#  'either',
#[Out]#  'eleven',
#[Out]#  'else',
#[Out]#  'elsewhere',
#[Out]#  'empty',
#[Out]#  'enough',
#[Out]#  'even',
#[Out]#  'ever',
#[Out]#  'every',
#[Out]#  'everyone',
#[Out]#  'everything',
#[Out]#  'everywhere',
#[Out]#  'except',
#[Out]#  'few',
#[Out]#  'fifteen',
#[Out]#  'fifty',
#[Out]#  'first',
#[Out]#  'five',
#[Out]#  'for',
#[Out]#  'former',
#[Out]#  'formerly',
#[Out]#  'forty',
#[Out]#  'four',
#[Out]#  'from',
#[Out]#  'front',
#[Out]#  'full',
#[Out]#  'further',
#[Out]#  'get',
#[Out]#  'give',
#[Out]#  'go',
#[Out]#  'had',
#[Out]#  'has',
#[Out]#  'have',
#[Out]#  'he',
#[Out]#  'hence',
#[Out]#  'her',
#[Out]#  'here',
#[Out]#  'hereafter',
#[Out]#  'hereby',
#[Out]#  'herein',
#[Out]#  'hereupon',
#[Out]#  'hers',
#[Out]#  'herself',
#[Out]#  'him',
#[Out]#  'himself',
#[Out]#  'his',
#[Out]#  'how',
#[Out]#  'however',
#[Out]#  'hundred',
#[Out]#  'i',
#[Out]#  'if',
#[Out]#  'in',
#[Out]#  'indeed',
#[Out]#  'into',
#[Out]#  'is',
#[Out]#  'it',
#[Out]#  'its',
#[Out]#  'itself',
#[Out]#  'just',
#[Out]#  'keep',
#[Out]#  'last',
#[Out]#  'latter',
#[Out]#  'latterly',
#[Out]#  'least',
#[Out]#  'less',
#[Out]#  'made',
#[Out]#  'make',
#[Out]#  'many',
#[Out]#  'may',
#[Out]#  'me',
#[Out]#  'meanwhile',
#[Out]#  'might',
#[Out]#  'mine',
#[Out]#  'more',
#[Out]#  'moreover',
#[Out]#  'most',
#[Out]#  'mostly',
#[Out]#  'move',
#[Out]#  'much',
#[Out]#  'must',
#[Out]#  'my',
#[Out]#  'myself',
#[Out]#  'name',
#[Out]#  'namely',
#[Out]#  'neither',
#[Out]#  'never',
#[Out]#  'nevertheless',
#[Out]#  'next',
#[Out]#  'nine',
#[Out]#  'no',
#[Out]#  'nobody',
#[Out]#  'none',
#[Out]#  'noone',
#[Out]#  'nor',
#[Out]#  'not',
#[Out]#  'nothing',
#[Out]#  'now',
#[Out]#  'nowhere',
#[Out]#  'of',
#[Out]#  'off',
#[Out]#  'often',
#[Out]#  'on',
#[Out]#  'once',
#[Out]#  'one',
#[Out]#  'only',
#[Out]#  'onto',
#[Out]#  'or',
#[Out]#  'other',
#[Out]#  'others',
#[Out]#  'otherwise',
#[Out]#  'our',
#[Out]#  'ours',
#[Out]#  'ourselves',
#[Out]#  'out',
#[Out]#  'over',
#[Out]#  'own',
#[Out]#  'part',
#[Out]#  'per',
#[Out]#  'perhaps',
#[Out]#  'please',
#[Out]#  'put',
#[Out]#  'python',
#[Out]#  'quite',
#[Out]#  'rather',
#[Out]#  're',
#[Out]#  'really',
#[Out]#  'regarding',
#[Out]#  'same',
#[Out]#  'say',
#[Out]#  'see',
#[Out]#  'seem',
#[Out]#  'seemed',
#[Out]#  'seeming',
#[Out]#  'seems',
#[Out]#  'serious',
#[Out]#  'several',
#[Out]#  'she',
#[Out]#  'should',
#[Out]#  'show',
#[Out]#  'side',
#[Out]#  'since',
#[Out]#  'six',
#[Out]#  'sixty',
#[Out]#  'so',
#[Out]#  'some',
#[Out]#  'somehow',
#[Out]#  'someone',
#[Out]#  'something',
#[Out]#  'sometime',
#[Out]#  'sometimes',
#[Out]#  'somewhere',
#[Out]#  'still',
#[Out]#  'such',
#[Out]#  'take',
#[Out]#  'ten',
#[Out]#  'than',
#[Out]#  'that',
#[Out]#  'the',
#[Out]#  'their',
#[Out]#  'them',
#[Out]#  'themselves',
#[Out]#  'then',
#[Out]#  'thence',
#[Out]#  'there',
#[Out]#  'thereafter',
#[Out]#  'thereby',
#[Out]#  'therefore',
#[Out]#  'therein',
#[Out]#  'thereupon',
#[Out]#  'these',
#[Out]#  'they',
#[Out]#  'third',
#[Out]#  'this',
#[Out]#  'those',
#[Out]#  'though',
#[Out]#  'three',
#[Out]#  'through',
#[Out]#  'throughout',
#[Out]#  'thru',
#[Out]#  'thus',
#[Out]#  'to',
#[Out]#  'together',
#[Out]#  'too',
#[Out]#  'top',
#[Out]#  'toward',
#[Out]#  'towards',
#[Out]#  'twelve',
#[Out]#  'twenty',
#[Out]#  'two',
#[Out]#  'under',
#[Out]#  'unless',
#[Out]#  'until',
#[Out]#  'up',
#[Out]#  'upon',
#[Out]#  'us',
#[Out]#  'used',
#[Out]#  'using',
#[Out]#  'various',
#[Out]#  'very',
#[Out]#  'via',
#[Out]#  'was',
#[Out]#  'we',
#[Out]#  'well',
#[Out]#  'were',
#[Out]#  'what',
#[Out]#  'whatever',
#[Out]#  'when',
#[Out]#  'whence',
#[Out]#  'whenever',
#[Out]#  'where',
#[Out]#  'whereafter',
#[Out]#  'whereas',
#[Out]#  'whereby',
#[Out]#  'wherein',
#[Out]#  'whereupon',
#[Out]#  'wherever',
#[Out]#  'whether',
#[Out]#  'which',
#[Out]#  'while',
#[Out]#  'whither',
#[Out]#  'who',
#[Out]#  'whoever',
#[Out]#  'whole',
#[Out]#  'whom',
#[Out]#  'whose',
#[Out]#  'why',
#[Out]#  'will',
#[Out]#  'with',
#[Out]#  'within',
#[Out]#  'without',
#[Out]#  'would',
#[Out]#  'yet',
#[Out]#  'you',
#[Out]#  'your',
#[Out]#  'yours',
#[Out]#  'yourself',
#[Out]#  'yourselves'}
# Wed, 18 Mar 2020 18:14:18
print([word.lemma_ for word in nlp('run runs ran running')])
print([word.lemma_ for word in nlp('buy buys buying bought')])
print([word.lemma_ for word in nlp('see saw seen seeing')])# Wed, 18 Mar 2020 18:14:19
from sklearn.feature_extraction.text import TfidfVectorizer

def lemmatizer(text):
    return [word.lemma_ for word in nlp(text)]

# we need to generate the lemmas of the stop words
stop_words_str = " ".join(STOP_WORDS) # nlp function needs a string
stop_words_lemma = set(word.lemma_ for word in nlp(stop_words_str))

tfidf_lemma = TfidfVectorizer(max_features=100, 
                              stop_words=stop_words_lemma.union({"python"}),
                              tokenizer=lemmatizer)

tfidf_lemma.fit(documents)
print(tfidf_lemma.get_feature_names())# Wed, 18 Mar 2020 18:14:29
bigram_counter=CountVectorizer(max_features=20, ngram_range=(2,2), stop_words=STOP_WORDS.union({"python"}))
bigram_counter.fit(documents)

bigram_counter.get_feature_names()#[Out]# ['23 ft',
#[Out]#  'arbitrary precision',
#[Out]#  'ball pythons',
#[Out]#  'floating point',
#[Out]#  'ft length',
#[Out]#  'integer division',
#[Out]#  'isbn 978',
#[Out]#  'list comprehensions',
#[Out]#  'number incremented',
#[Out]#  'object oriented',
#[Out]#  'oriented programming',
#[Out]#  'programming language',
#[Out]#  'programming languages',
#[Out]#  'reference implementation',
#[Out]#  'reticulated pythons',
#[Out]#  'scripting language',
#[Out]#  'standard library',
#[Out]#  'van rossum',
#[Out]#  'version number',
#[Out]#  'year old']
# Wed, 18 Mar 2020 18:14:29
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

# create data set and labels
documents = animal_sents + language_sents
labels = ["animal"]*len(animal_sents) + ["language"]*len(language_sents)

# lemma of stop words
stop_words_str = " ".join(STOP_WORDS)
stop_words_lemma = set(word.lemma_ for word in nlp(stop_words_str))

# create and train pipeline
tfidf = TfidfVectorizer(stop_words=stop_words_lemma, tokenizer=lemmatizer, ngram_range=(1, 2))
pipe = Pipeline([('vectorizer', tfidf), ('classifier', MultinomialNB())])
pipe.fit(documents, labels)

print("Training accuracy: {}".format(pipe.score(documents, labels)))# Wed, 18 Mar 2020 18:14:47
test_docs = ["My Python program is only 100 bytes long.",
             "A python's bite is not venomous but still hurts.",
             "I can't find the error in the python code.",
             "Where is my pet python; I can't find her!",
             "I use for and while loops when writing Python.",
             "The python will loop and wrap itself onto me.",
             "I use snake case for naming my variables.",
             "My python has grown to over 10 ft long!",
             "I use virtual environments to manage package versions.",
             "Pythons are the largest snakes in the environment."]

class_labels = ["animal", "language"]
y_proba = pipe.predict_proba(test_docs)
predicted_indices = (y_proba[:, 1] > 0.5).astype(int)

for i, index in enumerate(predicted_indices):
    print(test_docs[i], "--> {} at {:g}%".format(class_labels[index], 100*y_proba[i, index]))