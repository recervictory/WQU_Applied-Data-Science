# Wed, 18 Mar 2020 18:00:19
%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
# Wed, 18 Mar 2020 18:00:46
%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
# Wed, 18 Mar 2020 18:00:46
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn.datasets
from ipywidgets import interact# Wed, 18 Mar 2020 18:00:46
!wget http://dataincubator-wqu.s3.amazonaws.com/caldata/cal_housing.pkz -nc -P ~/scikit_learn_data/# Wed, 18 Mar 2020 18:00:46
from sklearn.datasets import fetch_california_housing

cali_data = fetch_california_housing()

cali_df = pd.DataFrame(cali_data.data, columns=cali_data.feature_names)
cali_df.head()#[Out]#    MedInc  HouseAge  AveRooms  AveBedrms  Population  AveOccup  Latitude  \
#[Out]# 0  8.3252      41.0  6.984127   1.023810       322.0  2.555556     37.88   
#[Out]# 1  8.3014      21.0  6.238137   0.971880      2401.0  2.109842     37.86   
#[Out]# 2  7.2574      52.0  8.288136   1.073446       496.0  2.802260     37.85   
#[Out]# 3  5.6431      52.0  5.817352   1.073059       558.0  2.547945     37.85   
#[Out]# 4  3.8462      52.0  6.281853   1.081081       565.0  2.181467     37.85   
#[Out]# 
#[Out]#    Longitude  
#[Out]# 0    -122.23  
#[Out]# 1    -122.22  
#[Out]# 2    -122.24  
#[Out]# 3    -122.25  
#[Out]# 4    -122.25  
# Wed, 18 Mar 2020 18:00:46
def plot_feature(feature):
    plt.plot(cali_df[feature], cali_data.target, '.')
    plt.xlabel(feature)
    plt.ylabel('Median home value')

menu = cali_data.feature_names

interact(plot_feature, feature=menu);# Wed, 18 Mar 2020 18:00:46
from sklearn import tree
from IPython import display
from graphviz import Source

model = tree.DecisionTreeRegressor(max_depth=2)
model.fit(cali_df['Longitude'].to_frame(), cali_data.target)

plt.plot(cali_df['Longitude'], cali_data.target, '.', label='data')
plt.plot(cali_df['Longitude'].sort_values(), 
         model.predict(cali_df['Longitude'].sort_values().to_frame()), 
         'r-', label='model')

plt.xlabel('Longitude')
plt.ylabel('Median home value')
plt.legend()

graph = Source(tree.export_graphviz(model, out_file=None, feature_names=['Longitude']))
display.SVG(graph.pipe(format='svg'))#[Out]# <IPython.core.display.SVG object>
# Wed, 18 Mar 2020 18:00:47
from sklearn.metrics import mean_squared_error as mse

max_depths = range(1, 20)
training_error = []
for max_depth in max_depths:
    model = tree.DecisionTreeRegressor(max_depth=max_depth)
    model.fit(cali_df['Latitude'].to_frame(), cali_data.target)
    training_error.append(mse(cali_data.target, model.predict(cali_df['Latitude'].to_frame())))

plt.plot(max_depths, training_error)
plt.xlabel('Maximum tree depth')
plt.ylabel('Mean squared error');# Wed, 18 Mar 2020 18:00:47
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle

X_train, X_test, y_train, y_test = train_test_split(*shuffle(cali_df['Longitude'].to_frame(), 
                                                             cali_data.target), test_size=0.1)

print(X_train.shape)
print(X_test.shape)# Wed, 18 Mar 2020 18:00:47
testing_error = []
for max_depth in max_depths:
    model = tree.DecisionTreeRegressor(max_depth=max_depth)
    model.fit(X_train, y_train)
    testing_error.append(mse(y_test, model.predict(X_test)))

plt.plot(max_depths, training_error, label='Training error')
plt.plot(max_depths, testing_error, label='Testing error')
plt.xlabel('Maximum tree depth')
plt.ylabel('Mean squared error')
plt.legend();# Wed, 18 Mar 2020 18:00:48
list(zip(max_depths, [sum([2**i for i in range(max_depth)]) for max_depth in max_depths]))#[Out]# [(1, 1),
#[Out]#  (2, 3),
#[Out]#  (3, 7),
#[Out]#  (4, 15),
#[Out]#  (5, 31),
#[Out]#  (6, 63),
#[Out]#  (7, 127),
#[Out]#  (8, 255),
#[Out]#  (9, 511),
#[Out]#  (10, 1023),
#[Out]#  (11, 2047),
#[Out]#  (12, 4095),
#[Out]#  (13, 8191),
#[Out]#  (14, 16383),
#[Out]#  (15, 32767),
#[Out]#  (16, 65535),
#[Out]#  (17, 131071),
#[Out]#  (18, 262143),
#[Out]#  (19, 524287)]
# Wed, 18 Mar 2020 18:00:48
from sklearn.model_selection import GridSearchCV

model = tree.DecisionTreeRegressor()

gs = GridSearchCV(model,
                  {'max_depth': range(1, 15),
                  'min_samples_split': range(10, 110, 10)},
                  cv=5,
                  n_jobs=2,
                  scoring='neg_mean_squared_error')

gs.fit(X_train, y_train)

print(gs.best_params_)# Wed, 18 Mar 2020 18:00:58
model = gs.best_estimator_
model.fit(X_train, y_train)

plt.plot(cali_df['Longitude'], cali_data.target, '.', label='data')
plt.plot(cali_df['Longitude'].sort_values(), model.predict(cali_df['Longitude'].sort_values().to_frame()), 'r-', label='model')
plt.xlabel('Longitude')
plt.ylabel('Median home value')
plt.legend()

print(mse(y_test, model.predict(X_test)))# Wed, 18 Mar 2020 18:00:59
from sklearn.neighbors import KNeighborsRegressor

tree_reg = tree.DecisionTreeRegressor()
knn_reg = KNeighborsRegressor()

estimators = {'tree_reg': tree_reg, 'knn_reg': knn_reg}
hyperparam_dict = {'tree_reg': {'min_samples_split': range(10, 110, 10), 'max_depth': range(1, 15)}, 'knn_reg': {'n_neighbors': range(10, 100, 10)}}

scores = {}
for name, estimator in estimators.items():
    gs = GridSearchCV(estimator,
                      hyperparam_dict[name],
                      cv=5,
                      n_jobs=2,
                      scoring='neg_mean_squared_error')
    
    gs.fit(X_train, y_train)

    scores[name] = -gs.best_score_

print(scores)# Wed, 18 Mar 2020 18:01:08
%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn.datasets
from ipywidgets import interact
!wget http://dataincubator-wqu.s3.amazonaws.com/caldata/cal_housing.pkz -nc -P ~/scikit_learn_data/
from sklearn.datasets import fetch_california_housing

cali_data = fetch_california_housing()

cali_df = pd.DataFrame(cali_data.data, columns=cali_data.feature_names)
cali_df.head()
#[Out]#    MedInc  HouseAge  AveRooms  AveBedrms  Population  AveOccup  Latitude  \
#[Out]# 0  8.3252      41.0  6.984127   1.023810       322.0  2.555556     37.88   
#[Out]# 1  8.3014      21.0  6.238137   0.971880      2401.0  2.109842     37.86   
#[Out]# 2  7.2574      52.0  8.288136   1.073446       496.0  2.802260     37.85   
#[Out]# 3  5.6431      52.0  5.817352   1.073059       558.0  2.547945     37.85   
#[Out]# 4  3.8462      52.0  6.281853   1.081081       565.0  2.181467     37.85   
#[Out]# 
#[Out]#    Longitude  
#[Out]# 0    -122.23  
#[Out]# 1    -122.22  
#[Out]# 2    -122.24  
#[Out]# 3    -122.25  
#[Out]# 4    -122.25  
def plot_feature(feature):
    plt.plot(cali_df[feature], cali_data.target, '.')
    plt.xlabel(feature)
    plt.ylabel('Median home value')

menu = cali_data.feature_names

interact(plot_feature, feature=menu);
from sklearn import tree
from IPython import display
from graphviz import Source

model = tree.DecisionTreeRegressor(max_depth=2)
model.fit(cali_df['Longitude'].to_frame(), cali_data.target)

plt.plot(cali_df['Longitude'], cali_data.target, '.', label='data')
plt.plot(cali_df['Longitude'].sort_values(), 
         model.predict(cali_df['Longitude'].sort_values().to_frame()), 
         'r-', label='model')

plt.xlabel('Longitude')
plt.ylabel('Median home value')
plt.legend()

graph = Source(tree.export_graphviz(model, out_file=None, feature_names=['Longitude']))
display.SVG(graph.pipe(format='svg'))
#[Out]# <IPython.core.display.SVG object>
from sklearn.metrics import mean_squared_error as mse

max_depths = range(1, 20)
training_error = []
for max_depth in max_depths:
    model = tree.DecisionTreeRegressor(max_depth=max_depth)
    model.fit(cali_df['Latitude'].to_frame(), cali_data.target)
    training_error.append(mse(cali_data.target, model.predict(cali_df['Latitude'].to_frame())))

plt.plot(max_depths, training_error)
plt.xlabel('Maximum tree depth')
plt.ylabel('Mean squared error');
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle

X_train, X_test, y_train, y_test = train_test_split(*shuffle(cali_df['Longitude'].to_frame(), 
                                                             cali_data.target), test_size=0.1)

print(X_train.shape)
print(X_test.shape)
testing_error = []
for max_depth in max_depths:
    model = tree.DecisionTreeRegressor(max_depth=max_depth)
    model.fit(X_train, y_train)
    testing_error.append(mse(y_test, model.predict(X_test)))

plt.plot(max_depths, training_error, label='Training error')
plt.plot(max_depths, testing_error, label='Testing error')
plt.xlabel('Maximum tree depth')
plt.ylabel('Mean squared error')
plt.legend();
list(zip(max_depths, [sum([2**i for i in range(max_depth)]) for max_depth in max_depths]))
#[Out]# [(1, 1), (2, 3), (3, 7), (4, 15), (5, 31), (6, 63), (7, 127), (8, 255), (9, 511), (10, 1023), (11, 2047), (12, 4095), (13, 8191), (14, 16383), (15, 32767), (16, 65535), (17, 131071), (18, 262143), (19, 524287)]
from sklearn.model_selection import GridSearchCV

model = tree.DecisionTreeRegressor()

gs = GridSearchCV(model,
                  {'max_depth': range(1, 15),
                  'min_samples_split': range(10, 110, 10)},
                  cv=5,
                  n_jobs=2,
                  scoring='neg_mean_squared_error')

gs.fit(X_train, y_train)

print(gs.best_params_)
model = gs.best_estimator_
model.fit(X_train, y_train)

plt.plot(cali_df['Longitude'], cali_data.target, '.', label='data')
plt.plot(cali_df['Longitude'].sort_values(), model.predict(cali_df['Longitude'].sort_values().to_frame()), 'r-', label='model')
plt.xlabel('Longitude')
plt.ylabel('Median home value')
plt.legend()

print(mse(y_test, model.predict(X_test)))
from sklearn.neighbors import KNeighborsRegressor

tree_reg = tree.DecisionTreeRegressor()
knn_reg = KNeighborsRegressor()

estimators = {'tree_reg': tree_reg, 'knn_reg': knn_reg}
hyperparam_dict = {'tree_reg': {'min_samples_split': range(10, 110, 10), 'max_depth': range(1, 15)}, 'knn_reg': {'n_neighbors': range(10, 100, 10)}}

scores = {}
for name, estimator in estimators.items():
    gs = GridSearchCV(estimator,
                      hyperparam_dict[name],
                      cv=5,
                      n_jobs=2,
                      scoring='neg_mean_squared_error')
    
    gs.fit(X_train, y_train)

    scores[name] = -gs.best_score_

print(scores)
# Wed, 18 Mar 2020 18:01:24
%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn.datasets
from ipywidgets import interact
!wget http://dataincubator-wqu.s3.amazonaws.com/caldata/cal_housing.pkz -nc -P ~/scikit_learn_data/
from sklearn.datasets import fetch_california_housing

cali_data = fetch_california_housing()

cali_df = pd.DataFrame(cali_data.data, columns=cali_data.feature_names)
cali_df.head()
#[Out]#    MedInc  HouseAge  AveRooms  AveBedrms  Population  AveOccup  Latitude  \
#[Out]# 0  8.3252      41.0  6.984127   1.023810       322.0  2.555556     37.88   
#[Out]# 1  8.3014      21.0  6.238137   0.971880      2401.0  2.109842     37.86   
#[Out]# 2  7.2574      52.0  8.288136   1.073446       496.0  2.802260     37.85   
#[Out]# 3  5.6431      52.0  5.817352   1.073059       558.0  2.547945     37.85   
#[Out]# 4  3.8462      52.0  6.281853   1.081081       565.0  2.181467     37.85   
#[Out]# 
#[Out]#    Longitude  
#[Out]# 0    -122.23  
#[Out]# 1    -122.22  
#[Out]# 2    -122.24  
#[Out]# 3    -122.25  
#[Out]# 4    -122.25  
def plot_feature(feature):
    plt.plot(cali_df[feature], cali_data.target, '.')
    plt.xlabel(feature)
    plt.ylabel('Median home value')

menu = cali_data.feature_names

interact(plot_feature, feature=menu);
from sklearn import tree
from IPython import display
from graphviz import Source

model = tree.DecisionTreeRegressor(max_depth=2)
model.fit(cali_df['Longitude'].to_frame(), cali_data.target)

plt.plot(cali_df['Longitude'], cali_data.target, '.', label='data')
plt.plot(cali_df['Longitude'].sort_values(), 
         model.predict(cali_df['Longitude'].sort_values().to_frame()), 
         'r-', label='model')

plt.xlabel('Longitude')
plt.ylabel('Median home value')
plt.legend()

graph = Source(tree.export_graphviz(model, out_file=None, feature_names=['Longitude']))
display.SVG(graph.pipe(format='svg'))
#[Out]# <IPython.core.display.SVG object>
from sklearn.metrics import mean_squared_error as mse

max_depths = range(1, 20)
training_error = []
for max_depth in max_depths:
    model = tree.DecisionTreeRegressor(max_depth=max_depth)
    model.fit(cali_df['Latitude'].to_frame(), cali_data.target)
    training_error.append(mse(cali_data.target, model.predict(cali_df['Latitude'].to_frame())))

plt.plot(max_depths, training_error)
plt.xlabel('Maximum tree depth')
plt.ylabel('Mean squared error');
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle

X_train, X_test, y_train, y_test = train_test_split(*shuffle(cali_df['Longitude'].to_frame(), 
                                                             cali_data.target), test_size=0.1)

print(X_train.shape)
print(X_test.shape)
testing_error = []
for max_depth in max_depths:
    model = tree.DecisionTreeRegressor(max_depth=max_depth)
    model.fit(X_train, y_train)
    testing_error.append(mse(y_test, model.predict(X_test)))

plt.plot(max_depths, training_error, label='Training error')
plt.plot(max_depths, testing_error, label='Testing error')
plt.xlabel('Maximum tree depth')
plt.ylabel('Mean squared error')
plt.legend();
list(zip(max_depths, [sum([2**i for i in range(max_depth)]) for max_depth in max_depths]))
#[Out]# [(1, 1), (2, 3), (3, 7), (4, 15), (5, 31), (6, 63), (7, 127), (8, 255), (9, 511), (10, 1023), (11, 2047), (12, 4095), (13, 8191), (14, 16383), (15, 32767), (16, 65535), (17, 131071), (18, 262143), (19, 524287)]
from sklearn.model_selection import GridSearchCV

model = tree.DecisionTreeRegressor()

gs = GridSearchCV(model,
                  {'max_depth': range(1, 15),
                  'min_samples_split': range(10, 110, 10)},
                  cv=5,
                  n_jobs=2,
                  scoring='neg_mean_squared_error')

gs.fit(X_train, y_train)

print(gs.best_params_)
model = gs.best_estimator_
model.fit(X_train, y_train)

plt.plot(cali_df['Longitude'], cali_data.target, '.', label='data')
plt.plot(cali_df['Longitude'].sort_values(), model.predict(cali_df['Longitude'].sort_values().to_frame()), 'r-', label='model')
plt.xlabel('Longitude')
plt.ylabel('Median home value')
plt.legend()

print(mse(y_test, model.predict(X_test)))
from sklearn.neighbors import KNeighborsRegressor

tree_reg = tree.DecisionTreeRegressor()
knn_reg = KNeighborsRegressor()

estimators = {'tree_reg': tree_reg, 'knn_reg': knn_reg}
hyperparam_dict = {'tree_reg': {'min_samples_split': range(10, 110, 10), 'max_depth': range(1, 15)}, 'knn_reg': {'n_neighbors': range(10, 100, 10)}}

scores = {}
for name, estimator in estimators.items():
    gs = GridSearchCV(estimator,
                      hyperparam_dict[name],
                      cv=5,
                      n_jobs=2,
                      scoring='neg_mean_squared_error')
    
    gs.fit(X_train, y_train)

    scores[name] = -gs.best_score_

print(scores)
%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
# Wed, 18 Mar 2020 18:01:34
%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
# Wed, 18 Mar 2020 18:01:34
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn.datasets
from ipywidgets import interact# Wed, 18 Mar 2020 18:01:34
!wget http://dataincubator-wqu.s3.amazonaws.com/caldata/cal_housing.pkz -nc -P ~/scikit_learn_data/# Wed, 18 Mar 2020 18:01:34
from sklearn.datasets import fetch_california_housing

cali_data = fetch_california_housing()

cali_df = pd.DataFrame(cali_data.data, columns=cali_data.feature_names)
cali_df.head()#[Out]#    MedInc  HouseAge  AveRooms  AveBedrms  Population  AveOccup  Latitude  \
#[Out]# 0  8.3252      41.0  6.984127   1.023810       322.0  2.555556     37.88   
#[Out]# 1  8.3014      21.0  6.238137   0.971880      2401.0  2.109842     37.86   
#[Out]# 2  7.2574      52.0  8.288136   1.073446       496.0  2.802260     37.85   
#[Out]# 3  5.6431      52.0  5.817352   1.073059       558.0  2.547945     37.85   
#[Out]# 4  3.8462      52.0  6.281853   1.081081       565.0  2.181467     37.85   
#[Out]# 
#[Out]#    Longitude  
#[Out]# 0    -122.23  
#[Out]# 1    -122.22  
#[Out]# 2    -122.24  
#[Out]# 3    -122.25  
#[Out]# 4    -122.25  
# Wed, 18 Mar 2020 18:01:34
def plot_feature(feature):
    plt.plot(cali_df[feature], cali_data.target, '.')
    plt.xlabel(feature)
    plt.ylabel('Median home value')

menu = cali_data.feature_names

interact(plot_feature, feature=menu);# Wed, 18 Mar 2020 18:01:35
from sklearn import tree
from IPython import display
from graphviz import Source

model = tree.DecisionTreeRegressor(max_depth=2)
model.fit(cali_df['Longitude'].to_frame(), cali_data.target)

plt.plot(cali_df['Longitude'], cali_data.target, '.', label='data')
plt.plot(cali_df['Longitude'].sort_values(), 
         model.predict(cali_df['Longitude'].sort_values().to_frame()), 
         'r-', label='model')

plt.xlabel('Longitude')
plt.ylabel('Median home value')
plt.legend()

graph = Source(tree.export_graphviz(model, out_file=None, feature_names=['Longitude']))
display.SVG(graph.pipe(format='svg'))#[Out]# <IPython.core.display.SVG object>
# Wed, 18 Mar 2020 18:01:35
from sklearn.metrics import mean_squared_error as mse

max_depths = range(1, 20)
training_error = []
for max_depth in max_depths:
    model = tree.DecisionTreeRegressor(max_depth=max_depth)
    model.fit(cali_df['Latitude'].to_frame(), cali_data.target)
    training_error.append(mse(cali_data.target, model.predict(cali_df['Latitude'].to_frame())))

plt.plot(max_depths, training_error)
plt.xlabel('Maximum tree depth')
plt.ylabel('Mean squared error');# Wed, 18 Mar 2020 18:01:36
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle

X_train, X_test, y_train, y_test = train_test_split(*shuffle(cali_df['Longitude'].to_frame(), 
                                                             cali_data.target), test_size=0.1)

print(X_train.shape)
print(X_test.shape)# Wed, 18 Mar 2020 18:01:36
testing_error = []
for max_depth in max_depths:
    model = tree.DecisionTreeRegressor(max_depth=max_depth)
    model.fit(X_train, y_train)
    testing_error.append(mse(y_test, model.predict(X_test)))

plt.plot(max_depths, training_error, label='Training error')
plt.plot(max_depths, testing_error, label='Testing error')
plt.xlabel('Maximum tree depth')
plt.ylabel('Mean squared error')
plt.legend();# Wed, 18 Mar 2020 18:01:36
list(zip(max_depths, [sum([2**i for i in range(max_depth)]) for max_depth in max_depths]))#[Out]# [(1, 1),
#[Out]#  (2, 3),
#[Out]#  (3, 7),
#[Out]#  (4, 15),
#[Out]#  (5, 31),
#[Out]#  (6, 63),
#[Out]#  (7, 127),
#[Out]#  (8, 255),
#[Out]#  (9, 511),
#[Out]#  (10, 1023),
#[Out]#  (11, 2047),
#[Out]#  (12, 4095),
#[Out]#  (13, 8191),
#[Out]#  (14, 16383),
#[Out]#  (15, 32767),
#[Out]#  (16, 65535),
#[Out]#  (17, 131071),
#[Out]#  (18, 262143),
#[Out]#  (19, 524287)]
# Wed, 18 Mar 2020 18:01:36
from sklearn.model_selection import GridSearchCV

model = tree.DecisionTreeRegressor()

gs = GridSearchCV(model,
                  {'max_depth': range(1, 15),
                  'min_samples_split': range(10, 110, 10)},
                  cv=5,
                  n_jobs=2,
                  scoring='neg_mean_squared_error')

gs.fit(X_train, y_train)

print(gs.best_params_)# Wed, 18 Mar 2020 18:01:46
model = gs.best_estimator_
model.fit(X_train, y_train)

plt.plot(cali_df['Longitude'], cali_data.target, '.', label='data')
plt.plot(cali_df['Longitude'].sort_values(), model.predict(cali_df['Longitude'].sort_values().to_frame()), 'r-', label='model')
plt.xlabel('Longitude')
plt.ylabel('Median home value')
plt.legend()

print(mse(y_test, model.predict(X_test)))# Wed, 18 Mar 2020 18:01:47
from sklearn.neighbors import KNeighborsRegressor

tree_reg = tree.DecisionTreeRegressor()
knn_reg = KNeighborsRegressor()

estimators = {'tree_reg': tree_reg, 'knn_reg': knn_reg}
hyperparam_dict = {'tree_reg': {'min_samples_split': range(10, 110, 10), 'max_depth': range(1, 15)}, 'knn_reg': {'n_neighbors': range(10, 100, 10)}}

scores = {}
for name, estimator in estimators.items():
    gs = GridSearchCV(estimator,
                      hyperparam_dict[name],
                      cv=5,
                      n_jobs=2,
                      scoring='neg_mean_squared_error')
    
    gs.fit(X_train, y_train)

    scores[name] = -gs.best_score_

print(scores)# Wed, 18 Mar 2020 18:01:56
%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
%logstop
%logstart -ortq ~/.logs/ML_ModelSelection.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn.datasets
from ipywidgets import interact
!wget http://dataincubator-wqu.s3.amazonaws.com/caldata/cal_housing.pkz -nc -P ~/scikit_learn_data/
from sklearn.datasets import fetch_california_housing

cali_data = fetch_california_housing()

cali_df = pd.DataFrame(cali_data.data, columns=cali_data.feature_names)
cali_df.head()
#[Out]#    MedInc  HouseAge  AveRooms  AveBedrms  Population  AveOccup  Latitude  \
#[Out]# 0  8.3252      41.0  6.984127   1.023810       322.0  2.555556     37.88   
#[Out]# 1  8.3014      21.0  6.238137   0.971880      2401.0  2.109842     37.86   
#[Out]# 2  7.2574      52.0  8.288136   1.073446       496.0  2.802260     37.85   
#[Out]# 3  5.6431      52.0  5.817352   1.073059       558.0  2.547945     37.85   
#[Out]# 4  3.8462      52.0  6.281853   1.081081       565.0  2.181467     37.85   
#[Out]# 
#[Out]#    Longitude  
#[Out]# 0    -122.23  
#[Out]# 1    -122.22  
#[Out]# 2    -122.24  
#[Out]# 3    -122.25  
#[Out]# 4    -122.25  
def plot_feature(feature):
    plt.plot(cali_df[feature], cali_data.target, '.')
    plt.xlabel(feature)
    plt.ylabel('Median home value')

menu = cali_data.feature_names

interact(plot_feature, feature=menu);
from sklearn import tree
from IPython import display
from graphviz import Source

model = tree.DecisionTreeRegressor(max_depth=2)
model.fit(cali_df['Longitude'].to_frame(), cali_data.target)

plt.plot(cali_df['Longitude'], cali_data.target, '.', label='data')
plt.plot(cali_df['Longitude'].sort_values(), 
         model.predict(cali_df['Longitude'].sort_values().to_frame()), 
         'r-', label='model')

plt.xlabel('Longitude')
plt.ylabel('Median home value')
plt.legend()

graph = Source(tree.export_graphviz(model, out_file=None, feature_names=['Longitude']))
display.SVG(graph.pipe(format='svg'))
#[Out]# <IPython.core.display.SVG object>
from sklearn.metrics import mean_squared_error as mse

max_depths = range(1, 20)
training_error = []
for max_depth in max_depths:
    model = tree.DecisionTreeRegressor(max_depth=max_depth)
    model.fit(cali_df['Latitude'].to_frame(), cali_data.target)
    training_error.append(mse(cali_data.target, model.predict(cali_df['Latitude'].to_frame())))

plt.plot(max_depths, training_error)
plt.xlabel('Maximum tree depth')
plt.ylabel('Mean squared error');
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle

X_train, X_test, y_train, y_test = train_test_split(*shuffle(cali_df['Longitude'].to_frame(), 
                                                             cali_data.target), test_size=0.1)

print(X_train.shape)
print(X_test.shape)
testing_error = []
for max_depth in max_depths:
    model = tree.DecisionTreeRegressor(max_depth=max_depth)
    model.fit(X_train, y_train)
    testing_error.append(mse(y_test, model.predict(X_test)))

plt.plot(max_depths, training_error, label='Training error')
plt.plot(max_depths, testing_error, label='Testing error')
plt.xlabel('Maximum tree depth')
plt.ylabel('Mean squared error')
plt.legend();
list(zip(max_depths, [sum([2**i for i in range(max_depth)]) for max_depth in max_depths]))
#[Out]# [(1, 1), (2, 3), (3, 7), (4, 15), (5, 31), (6, 63), (7, 127), (8, 255), (9, 511), (10, 1023), (11, 2047), (12, 4095), (13, 8191), (14, 16383), (15, 32767), (16, 65535), (17, 131071), (18, 262143), (19, 524287)]
from sklearn.model_selection import GridSearchCV

model = tree.DecisionTreeRegressor()

gs = GridSearchCV(model,
                  {'max_depth': range(1, 15),
                  'min_samples_split': range(10, 110, 10)},
                  cv=5,
                  n_jobs=2,
                  scoring='neg_mean_squared_error')

gs.fit(X_train, y_train)

print(gs.best_params_)
model = gs.best_estimator_
model.fit(X_train, y_train)

plt.plot(cali_df['Longitude'], cali_data.target, '.', label='data')
plt.plot(cali_df['Longitude'].sort_values(), model.predict(cali_df['Longitude'].sort_values().to_frame()), 'r-', label='model')
plt.xlabel('Longitude')
plt.ylabel('Median home value')
plt.legend()

print(mse(y_test, model.predict(X_test)))
from sklearn.neighbors import KNeighborsRegressor

tree_reg = tree.DecisionTreeRegressor()
knn_reg = KNeighborsRegressor()

estimators = {'tree_reg': tree_reg, 'knn_reg': knn_reg}
hyperparam_dict = {'tree_reg': {'min_samples_split': range(10, 110, 10), 'max_depth': range(1, 15)}, 'knn_reg': {'n_neighbors': range(10, 100, 10)}}

scores = {}
for name, estimator in estimators.items():
    gs = GridSearchCV(estimator,
                      hyperparam_dict[name],
                      cv=5,
                      n_jobs=2,
                      scoring='neg_mean_squared_error')
    
    gs.fit(X_train, y_train)

    scores[name] = -gs.best_score_

print(scores)
