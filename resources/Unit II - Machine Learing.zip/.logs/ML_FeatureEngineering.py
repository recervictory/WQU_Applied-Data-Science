# Wed, 18 Mar 2020 18:03:55
%logstop
%logstart -ortq ~/.logs/ML_FeatureEngineering.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144%logstop
%logstart -ortq ~/.logs/ML_FeatureEngineering.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144
# Wed, 18 Mar 2020 18:03:55
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt# Wed, 18 Mar 2020 18:03:55
x1 = np.random.randn(100)
x2 = np.random.randn(100)
y = np.random.choice([True, False], size=100)

plt.figure(figsize=(8,8))
plt.plot(x1[y], x2[y], 'b.')
plt.plot(x1[~y], x2[~y], 'r.');# Wed, 18 Mar 2020 18:03:55
random_df = pd.DataFrame(np.vstack([x1, x2, y]).T, columns=['x1', 'x2', 'y'])
random_df.head()#[Out]#          x1        x2    y
#[Out]# 0 -0.534703  0.547812  0.0
#[Out]# 1 -1.967318 -0.434592  1.0
#[Out]# 2 -0.088218  0.507716  1.0
#[Out]# 3 -0.482443  0.914689  1.0
#[Out]# 4 -0.048413  3.138788  1.0
# Wed, 18 Mar 2020 18:03:55
random_df.corr()#[Out]#           x1        x2         y
#[Out]# x1  1.000000  0.060817 -0.034670
#[Out]# x2  0.060817  1.000000  0.215062
#[Out]# y  -0.034670  0.215062  1.000000
# Wed, 18 Mar 2020 18:03:55
temps = pd.read_csv('./data/land_temps_by_city.csv', parse_dates=[0])
temps.head()#[Out]#           dt  AverageTemperature  AverageTemperatureUncertainty    City  \
#[Out]# 0 1900-02-01               0.969                          0.585  Berlin   
#[Out]# 1 1900-03-01               1.313                          0.328  Berlin   
#[Out]# 2 1900-04-01               7.246                          0.317  Berlin   
#[Out]# 3 1900-05-01              12.125                          0.240  Berlin   
#[Out]# 4 1900-06-01              17.362                          0.343  Berlin   
#[Out]# 
#[Out]#    Country Latitude Longitude  
#[Out]# 0  Germany   52.24N    13.14E  
#[Out]# 1  Germany   52.24N    13.14E  
#[Out]# 2  Germany   52.24N    13.14E  
#[Out]# 3  Germany   52.24N    13.14E  
#[Out]# 4  Germany   52.24N    13.14E  
# Wed, 18 Mar 2020 18:03:55
from functools import reduce
def collect(x):
    return reduce(lambda y, z: y + [z] if isinstance(y, list) else [z], x)

def estimated_autocorrelation(x):
    n = len(x)
    variance = x.var()
    x = x-x.mean()
    r = np.correlate(x, x, mode = 'full')[-n:]
    result = r/(variance*(np.arange(n, 0, -1)))
    return result# Wed, 18 Mar 2020 18:03:55
plt.plot(estimated_autocorrelation(temps[temps['City']=='Berlin']['AverageTemperature'].values)[:12], label='Berlin')
plt.plot(estimated_autocorrelation(temps[temps['City']=='Jakarta']['AverageTemperature'].values)[:12], label='Jakarta')
plt.legend();# Wed, 18 Mar 2020 18:03:56
ac = temps.groupby('City')['AverageTemperature'].apply(collect).apply(lambda x: np.array(x)).apply(estimated_autocorrelation).rename('autocorr')
ac_lat = pd.concat([ac.apply(lambda x: x[range(6, 1362, 12)].mean()), temps[['City', 'Latitude']].drop_duplicates().set_index('City')], axis=1)
ac_lat['Latitude'] = ac_lat['Latitude'].apply(lambda x: float(x[:-1]))# Wed, 18 Mar 2020 18:03:56
plt.plot(ac_lat['Latitude'], ac_lat['autocorr'], '.')
plt.xlabel('Latitude')
plt.ylabel('6-month temperature autocorrelation');

ax = plt.gca()
labels = {'Lima', 'Shenzhen', 'Delhi', 'Lima', 'Kingston', 'Cape Town', 'Jakarta', 'Nairobi', 'Rio De Janeiro', 'Quito', 'Port Moresby', 'Seoul', 'Moscow', 'Paris', 'Toronto'}
for city in ac_lat.index:
    if city in labels:
        plt.text(ac_lat.loc[city, 'Latitude'], ac_lat.loc[city, 'autocorr'] + .01, city)# Wed, 18 Mar 2020 18:03:56
from sklearn.linear_model import LinearRegression

lin_reg = LinearRegression().fit(ac_lat['Latitude'].values.reshape(-1, 1), ac_lat['autocorr'].values.reshape(-1, 1))

ac_lat.sort_values('Latitude', inplace=True)

plt.plot(ac_lat['Latitude'], ac_lat['autocorr'], '.')
plt.plot(ac_lat['Latitude'], lin_reg.predict(ac_lat['Latitude'].values.reshape(-1, 1)))
plt.xlabel("Latitude")
plt.ylabel('6-month temperature autocorrelation');# Wed, 18 Mar 2020 18:03:56
plt.plot(np.exp(-ac_lat['Latitude']/13), ac_lat['autocorr'], '.')
plt.xlabel('Latitude')
plt.ylabel('6-month temperature autocorrelation');# Wed, 18 Mar 2020 18:03:57
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error as mse
from sklearn.utils import shuffle

X_train, X_test, y_train, y_test = train_test_split(*shuffle(ac_lat['Latitude'].values.reshape(-1, 1), ac_lat['autocorr'].values.reshape(-1, 1)), test_size=0.1)

lin_reg = LinearRegression()

lin_reg.fit(np.exp(-X_train/13), y_train)

lin_pred = lin_reg.predict(np.exp(-X_test/13))# Wed, 18 Mar 2020 18:03:57
from sklearn.tree import DecisionTreeRegressor

tree_reg = DecisionTreeRegressor(max_depth=3)
tree_reg.fit(X_train, y_train)
tree_pred = tree_reg.predict(X_test)# Wed, 18 Mar 2020 18:03:57
ac_lat.sort_values('Latitude', inplace=True)

plt.plot(ac_lat['Latitude'], ac_lat['autocorr'], '.', label='data')
plt.plot(ac_lat['Latitude'], lin_reg.predict(np.exp(-ac_lat['Latitude'].values.reshape(-1, 1) / 13)))
plt.plot(ac_lat['Latitude'], tree_reg.predict(ac_lat['Latitude'].values.reshape(-1, 1)))
plt.xlabel('Latitude')
plt.ylabel('6-month temperature autocorrelation');

print('Transformed linear regression: %0.2f' % mse(y_test, lin_pred))
print('Decision tree regression: %0.2f' % mse(y_test, tree_pred))# Wed, 18 Mar 2020 18:03:57
n = 1000
x1 = np.concatenate([np.random.randn(n // 2), np.random.randn(n // 2) + 2])
y = np.array([True if i < n // 2 else False for i in range(n)])

plt.figure(figsize=(8,8))
plt.hist(x1[y], alpha=.8)
plt.hist(x1[~y], alpha=.8);# Wed, 18 Mar 2020 18:03:57
x2 = np.concatenate([np.random.randn(n // 2), np.random.randn(n // 2) + 2])

plt.figure(figsize=(8,8))
plt.plot(x1[y], x2[y], 'b.')
plt.plot(x1[~y], x2[~y], 'r.');# Wed, 18 Mar 2020 18:03:58
np.vstack([x1, x2]).T#[Out]# array([[-0.2366846 ,  0.69805697],
#[Out]#        [-0.86668864,  0.55697371],
#[Out]#        [-0.33882646,  0.2361415 ],
#[Out]#        ...,
#[Out]#        [ 2.80236468,  3.02774677],
#[Out]#        [ 1.50589913,  2.56582517],
#[Out]#        [ 3.23185009,  1.79278364]])
# Wed, 18 Mar 2020 18:03:58
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

X_train, X_test, y_train, y_test = train_test_split(np.vstack([x1, x2]).T, y)

log_reg_1d = LogisticRegression(solver='lbfgs').fit(np.atleast_2d(X_train[:, 0]).T, y_train)

log_reg_2d = LogisticRegression(solver='lbfgs').fit(X_train, y_train)

print('Score on 1D data: %0.2f' % accuracy_score(y_test, log_reg_1d.predict(np.atleast_2d(X_test[:, 0]).T)))
print('Score on 2D data: %0.2f' % accuracy_score(y_test, log_reg_2d.predict(X_test)))# Wed, 18 Mar 2020 18:03:58
from matplotlib.colors import ListedColormap

xx1, xx2 = np.meshgrid(np.arange(-4, 6, .1), np.arange(-4, 6, .1))

Z = log_reg_2d.predict(np.array([xx1.ravel(), xx2.ravel()]).T)
Z = Z.reshape(xx1.shape)

cut_1d = np.arange(-4, 6, .1)[log_reg_1d.predict_proba(np.atleast_2d(np.arange(-4,6,.1)).T)[:, 0] > .5][0]

colors = ('red', 'blue')
cmap = ListedColormap(colors)

plt.contourf(xx1, xx2, Z, alpha=0.4, cmap=cmap)
plt.plot(x1[y], x2[y], 'b.')
plt.plot(x1[~y], x2[~y], 'r.')
plt.axvline(cut_1d, color='k', linestyle='--');# Wed, 18 Mar 2020 18:03:58
!wget http://dataincubator-wqu.s3.amazonaws.com/caldata/cal_housing.pkz -nc -P ~/scikit_learn_data/# Wed, 18 Mar 2020 18:03:58
from sklearn.datasets import fetch_california_housing

cali_data = fetch_california_housing()

cali_df = pd.DataFrame(cali_data.data, columns=cali_data.feature_names)# Wed, 18 Mar 2020 18:03:58
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import RandomizedSearchCV
from sklearn.metrics import r2_score
import scipy.stats

X_train, X_test, y_train, y_test = train_test_split(*shuffle(cali_df, cali_data.target), test_size=0.1)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)

model = DecisionTreeRegressor()

rs = RandomizedSearchCV(model,
                  {'max_depth': scipy.stats.binom(9, .3, loc=1),
                  'min_samples_split': scipy.stats.binom(90, .5, loc=10)},
                   cv=5,
                   n_iter=200,
                   n_jobs=4,
                   scoring='neg_mean_squared_error')

rs.fit(X_train, y_train)
print(r2_score(y_test, rs.best_estimator_.predict(scaler.transform(X_test))))

list(zip(cali_data.feature_names, rs.best_estimator_.feature_importances_))#[Out]# [('MedInc', 0.6656359560274338),
#[Out]#  ('HouseAge', 0.041262878364296866),
#[Out]#  ('AveRooms', 0.0269774996626759),
#[Out]#  ('AveBedrms', 0.005336063753783868),
#[Out]#  ('Population', 0.009211482913202614),
#[Out]#  ('AveOccup', 0.1349671852500436),
#[Out]#  ('Latitude', 0.05532440618269043),
#[Out]#  ('Longitude', 0.061284527845873)]
# Wed, 18 Mar 2020 18:04:51
X_train, X_test, y_train, y_test = train_test_split(*shuffle(cali_df, cali_data.target), test_size=0.1)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)

lin_reg = LinearRegression().fit(X_train, y_train)

print(r2_score(y_test, lin_reg.predict(scaler.transform(X_test))))

list(zip(cali_data.feature_names, abs(lin_reg.coef_) / sum(abs(lin_reg.coef_))))#[Out]# [('MedInc', 0.2534026099937284),
#[Out]#  ('HouseAge', 0.035174642080803314),
#[Out]#  ('AveRooms', 0.08432398441994361),
#[Out]#  ('AveBedrms', 0.09142145778178218),
#[Out]#  ('Population', 0.0015240562158920826),
#[Out]#  ('AveOccup', 0.01210760282720646),
#[Out]#  ('Latitude', 0.2648071995090968),
#[Out]#  ('Longitude', 0.2572384471715471)]
# Wed, 18 Mar 2020 18:04:51
from sklearn.feature_selection import RFECV

feature_elimination = RFECV(estimator=model, cv=5, scoring='r2')
feature_elimination.fit(X_train, y_train)

rfecv_scores = feature_elimination.grid_scores_
plt.plot(range(1, len(rfecv_scores) + 1), rfecv_scores)
plt.xlabel('Number of features used')
plt.ylabel(r'Cross validation score ($R^2$)');# Wed, 18 Mar 2020 18:04:56
from sklearn.linear_model import Ridge, Lasso
X_train, X_test, y_train, y_test = train_test_split(*shuffle(cali_df, cali_data.target), test_size=0.1)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)

lin_reg = LinearRegression().fit(X_train, y_train)

alphas = np.logspace(-2, 2, 100)
ridge_coefs = []
ridge_scores = []
lasso_coefs = []
lasso_scores = []
for alpha in alphas:
    ridge_reg = Ridge(alpha=alpha).fit(X_train, y_train)
    lasso_reg = Lasso(alpha=alpha).fit(X_train, y_train)
    ridge_coefs.append(ridge_reg.coef_)
    ridge_scores.append(r2_score(y_test, ridge_reg.predict(scaler.transform(X_test))))
    lasso_coefs.append(lasso_reg.coef_)
    lasso_scores.append(r2_score(y_test, lasso_reg.predict(scaler.transform(X_test))))

lin_score = r2_score(y_test, lin_reg.predict(scaler.transform(X_test)))
print('Linear regression score: %0.2f' % lin_score)
print('Ridge regression score: %0.2f' % max(ridge_scores))
print('Lasso regression score: %0.2f' % max(lasso_scores))# Wed, 18 Mar 2020 18:04:57
plt.figure()
plt.gca().set_xscale('log')
plt.gca().set_ylim([.5, .625])
plt.plot(alphas, np.repeat(lin_score, len(alphas)), label='simple')
plt.plot(alphas, ridge_scores, label='ridge')
plt.plot(alphas, lasso_scores, label='lasso')
plt.xlabel(r'Regularization strength ($\alpha$)')
plt.ylabel(r'$R^2$ score')
plt.legend();# Wed, 18 Mar 2020 18:04:57
plt.figure(figsize=[12, 8])
plt.title('Regression coefficients')

plt.subplot(311)
plt.gca().set_xscale('log')
plt.ylabel('Simple regression coefficients')
for coef in lin_reg.coef_:
    plt.plot(alphas, np.repeat(coef, len(alphas)))

plt.subplot(312)
plt.gca().set_xscale('log')
plt.ylabel('Ridge regression coefficients')
plt.plot(alphas, ridge_coefs)

plt.subplot(313)
plt.gca().set_xscale('log')
plt.ylabel('Lasso regression coefficients')
plt.xlabel(r'Regularization strength ($\alpha$)')
plt.plot(alphas, lasso_coefs);# Wed, 18 Mar 2020 18:04:59
x = 15
print(alphas[x], lasso_scores[x])
list(zip(cali_data.feature_names, lasso_coefs[x]))#[Out]# [('MedInc', 0.7338399089970102),
#[Out]#  ('HouseAge', 0.13888373108975033),
#[Out]#  ('AveRooms', -0.0),
#[Out]#  ('AveBedrms', 0.0),
#[Out]#  ('Population', 0.0),
#[Out]#  ('AveOccup', -0.0013433625874286444),
#[Out]#  ('Latitude', -0.3891871533634729),
#[Out]#  ('Longitude', -0.3470890944279244)]
# Wed, 18 Mar 2020 18:04:59
corr = cali_df.corr()
mask = np.zeros_like(corr, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

cmap = sns.diverging_palette(220, 10, as_cmap=True)

sns.heatmap(corr, mask=mask, cmap=cmap, square=True, linewidths=.5, center=0, vmax=1);# Wed, 18 Mar 2020 18:04:59
from ipywidgets import interact

def plot_data(rotation=0):
    x1_r = x1 * np.cos(rotation) + x2 * np.sin(rotation)
    x2_r = -x1 * np.sin(rotation) + x2 * np.cos(rotation)
    plt.plot(x1_r[y], x2_r[y], 'b.')
    plt.plot(x1_r[~y], x2_r[~y], 'r.')

    w1, w2 = log_reg_2d.coef_[0]
    x = np.sort(x1)
    line = (-log_reg_2d.intercept_ - w1 * x) / w2
    x_r = x * np.cos(rotation) + line * np.sin(rotation)
    line_r = -x * np.sin(rotation) + line * np.cos(rotation)
    plt.plot(x_r, line_r)
    
interact(plot_data, rotation=(0, np.pi, .1));# Wed, 18 Mar 2020 18:05:00
from sklearn.decomposition import PCA

X_train, X_test, y_train, y_test = train_test_split(np.vstack([x1, x2]).T, y)

pca = PCA(n_components=1)
X_pca_train = pca.fit_transform(X_train)
X_pca_test = pca.transform(X_test)

log_reg_pca = LogisticRegression(solver='lbfgs').fit(X_pca_train, y_train)

print('Score on 2D data: %0.2f' % accuracy_score(y_test, log_reg_2d.predict(X_test)))
print('Score on 1D data (PCA): %0.2f' % accuracy_score(y_test, log_reg_pca.predict(X_pca_test)))# Wed, 18 Mar 2020 18:05:00
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import GridSearchCV
X_train, X_test, y_train, y_test = train_test_split(*shuffle(cali_df, cali_data.target), test_size=0.1)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)# Wed, 18 Mar 2020 18:05:00
model = RandomForestRegressor(n_estimators=50)

gs = GridSearchCV(model,
                  {'max_features': np.arange(.05, 1, .05)},
                  cv=5,
                  n_jobs=4,
                  scoring='neg_mean_squared_error')

gs.fit(X_train, y_train)

model = gs.best_estimator_

print(gs.best_params_)
print(r2_score(y_test, model.predict(scaler.transform(X_test))))# Wed, 18 Mar 2020 18:09:10
gs = GridSearchCV(model,
                  {'min_samples_leaf': np.arange(1, 50, 5)},
                  cv=5,
                  n_jobs=4,
                  scoring='neg_mean_squared_error')

gs.fit(X_train, y_train)

model = gs.best_estimator_

print(gs.best_params_)
print(r2_score(y_test, model.predict(scaler.transform(X_test))))# Wed, 18 Mar 2020 18:10:23
gs = GridSearchCV(model,
                  {'n_estimators': np.arange(100, 301, 100)},
                  cv=5,
                  n_jobs=4,
                  scoring='neg_mean_squared_error')

gs.fit(X_train, y_train)

model = gs.best_estimator_

print(gs.best_params_)
print(r2_score(y_test, model.predict(scaler.transform(X_test))))# Wed, 18 Mar 2020 18:10:53
gs = GridSearchCV(model,
                  {'n_estimators': np.arange(100, 301, 100)},
                  cv=5,
                  n_jobs=4,
                  scoring='neg_mean_squared_error')

gs.fit(X_train, y_train)

model = gs.best_estimator_

print(gs.best_params_)
print(r2_score(y_test, model.predict(scaler.transform(X_test))))# Wed, 18 Mar 2020 18:11:36
from sklearn.base import BaseEstimator, TransformerMixin

class EstTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, estimator):
        self.estimator = estimator
    
    def fit(self, X, y):
        self.estimator.fit(X, y)
        return self

    def transform(self, X):
        return np.atleast_2d(self.estimator.predict(X)).T# Wed, 18 Mar 2020 18:11:39
from sklearn.neighbors import KNeighborsRegressor
from sklearn.pipeline import Pipeline

X_train, X_test, y_train, y_test = train_test_split(*shuffle(cali_df, cali_data.target), test_size=0.1)

knn = Pipeline([
    ('scaler', StandardScaler()),
    ('knn', KNeighborsRegressor())
])

gs = GridSearchCV(knn,
                  {'knn__n_neighbors': range(5, 26, 5)},
                  cv=5,
                  n_jobs=4,
                  scoring='neg_mean_squared_error')

gs.fit(X_train, y_train)
print(gs.best_params_)
print(r2_score(y_test, gs.best_estimator_.predict(X_test)))# Wed, 18 Mar 2020 18:11:53
from sklearn.pipeline import FeatureUnion

ensemble = FeatureUnion([
    ('rf', EstTransformer(DecisionTreeRegressor(max_depth=5, min_samples_split=45))),
    ('knn', EstTransformer(KNeighborsRegressor(n_neighbors=10)))
])

model = Pipeline([
    ('scaler', StandardScaler()),
    ('ensemble', ensemble),
    ('combine', LinearRegression(fit_intercept=False))
    ])

model.fit(X_train, y_train)

print(r2_score(y_test, model.predict(X_test)))